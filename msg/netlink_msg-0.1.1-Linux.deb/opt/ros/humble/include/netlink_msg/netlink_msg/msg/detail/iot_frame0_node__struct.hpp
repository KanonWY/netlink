// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from netlink_msg:msg/IotFrame0Node.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__IOT_FRAME0_NODE__STRUCT_HPP_
#define NETLINK_MSG__MSG__DETAIL__IOT_FRAME0_NODE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__netlink_msg__msg__IotFrame0Node __attribute__((deprecated))
#else
# define DEPRECATED__netlink_msg__msg__IotFrame0Node __declspec(deprecated)
#endif

namespace netlink_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct IotFrame0Node_
{
  using Type = IotFrame0Node_<ContainerAllocator>;

  explicit IotFrame0Node_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->uid = 0ul;
      this->dis = 0.0f;
      this->aoa_angle_horizontal = 0.0f;
      this->aoa_angle_vertical = 0.0f;
      this->fp_rssi = 0.0f;
      this->rx_rssi = 0.0f;
      this->user_data = "";
    }
  }

  explicit IotFrame0Node_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : user_data(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->uid = 0ul;
      this->dis = 0.0f;
      this->aoa_angle_horizontal = 0.0f;
      this->aoa_angle_vertical = 0.0f;
      this->fp_rssi = 0.0f;
      this->rx_rssi = 0.0f;
      this->user_data = "";
    }
  }

  // field types and members
  using _uid_type =
    uint32_t;
  _uid_type uid;
  using _dis_type =
    float;
  _dis_type dis;
  using _aoa_angle_horizontal_type =
    float;
  _aoa_angle_horizontal_type aoa_angle_horizontal;
  using _aoa_angle_vertical_type =
    float;
  _aoa_angle_vertical_type aoa_angle_vertical;
  using _fp_rssi_type =
    float;
  _fp_rssi_type fp_rssi;
  using _rx_rssi_type =
    float;
  _rx_rssi_type rx_rssi;
  using _user_data_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _user_data_type user_data;

  // setters for named parameter idiom
  Type & set__uid(
    const uint32_t & _arg)
  {
    this->uid = _arg;
    return *this;
  }
  Type & set__dis(
    const float & _arg)
  {
    this->dis = _arg;
    return *this;
  }
  Type & set__aoa_angle_horizontal(
    const float & _arg)
  {
    this->aoa_angle_horizontal = _arg;
    return *this;
  }
  Type & set__aoa_angle_vertical(
    const float & _arg)
  {
    this->aoa_angle_vertical = _arg;
    return *this;
  }
  Type & set__fp_rssi(
    const float & _arg)
  {
    this->fp_rssi = _arg;
    return *this;
  }
  Type & set__rx_rssi(
    const float & _arg)
  {
    this->rx_rssi = _arg;
    return *this;
  }
  Type & set__user_data(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->user_data = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    netlink_msg::msg::IotFrame0Node_<ContainerAllocator> *;
  using ConstRawPtr =
    const netlink_msg::msg::IotFrame0Node_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::IotFrame0Node_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::IotFrame0Node_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__netlink_msg__msg__IotFrame0Node
    std::shared_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__netlink_msg__msg__IotFrame0Node
    std::shared_ptr<netlink_msg::msg::IotFrame0Node_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const IotFrame0Node_ & other) const
  {
    if (this->uid != other.uid) {
      return false;
    }
    if (this->dis != other.dis) {
      return false;
    }
    if (this->aoa_angle_horizontal != other.aoa_angle_horizontal) {
      return false;
    }
    if (this->aoa_angle_vertical != other.aoa_angle_vertical) {
      return false;
    }
    if (this->fp_rssi != other.fp_rssi) {
      return false;
    }
    if (this->rx_rssi != other.rx_rssi) {
      return false;
    }
    if (this->user_data != other.user_data) {
      return false;
    }
    return true;
  }
  bool operator!=(const IotFrame0Node_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct IotFrame0Node_

// alias to use template instance with default allocator
using IotFrame0Node =
  netlink_msg::msg::IotFrame0Node_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__IOT_FRAME0_NODE__STRUCT_HPP_
