// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from netlink_msg:msg/LinktrackAoaNode0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__TRAITS_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "netlink_msg/msg/detail/linktrack_aoa_node0__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace netlink_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const LinktrackAoaNode0 & msg,
  std::ostream & out)
{
  out << "{";
  // member: role
  {
    out << "role: ";
    rosidl_generator_traits::value_to_yaml(msg.role, out);
    out << ", ";
  }

  // member: id
  {
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << ", ";
  }

  // member: dis
  {
    out << "dis: ";
    rosidl_generator_traits::value_to_yaml(msg.dis, out);
    out << ", ";
  }

  // member: angle
  {
    out << "angle: ";
    rosidl_generator_traits::value_to_yaml(msg.angle, out);
    out << ", ";
  }

  // member: fp_rssi
  {
    out << "fp_rssi: ";
    rosidl_generator_traits::value_to_yaml(msg.fp_rssi, out);
    out << ", ";
  }

  // member: rx_rssi
  {
    out << "rx_rssi: ";
    rosidl_generator_traits::value_to_yaml(msg.rx_rssi, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const LinktrackAoaNode0 & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: role
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "role: ";
    rosidl_generator_traits::value_to_yaml(msg.role, out);
    out << "\n";
  }

  // member: id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << "\n";
  }

  // member: dis
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dis: ";
    rosidl_generator_traits::value_to_yaml(msg.dis, out);
    out << "\n";
  }

  // member: angle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "angle: ";
    rosidl_generator_traits::value_to_yaml(msg.angle, out);
    out << "\n";
  }

  // member: fp_rssi
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fp_rssi: ";
    rosidl_generator_traits::value_to_yaml(msg.fp_rssi, out);
    out << "\n";
  }

  // member: rx_rssi
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rx_rssi: ";
    rosidl_generator_traits::value_to_yaml(msg.rx_rssi, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const LinktrackAoaNode0 & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace netlink_msg

namespace rosidl_generator_traits
{

[[deprecated("use netlink_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const netlink_msg::msg::LinktrackAoaNode0 & msg,
  std::ostream & out, size_t indentation = 0)
{
  netlink_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use netlink_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const netlink_msg::msg::LinktrackAoaNode0 & msg)
{
  return netlink_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<netlink_msg::msg::LinktrackAoaNode0>()
{
  return "netlink_msg::msg::LinktrackAoaNode0";
}

template<>
inline const char * name<netlink_msg::msg::LinktrackAoaNode0>()
{
  return "netlink_msg/msg/LinktrackAoaNode0";
}

template<>
struct has_fixed_size<netlink_msg::msg::LinktrackAoaNode0>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<netlink_msg::msg::LinktrackAoaNode0>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<netlink_msg::msg::LinktrackAoaNode0>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__TRAITS_HPP_
