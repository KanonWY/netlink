// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/TofsenseCascade.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/tofsense_cascade__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_TofsenseCascade_nodes
{
public:
  Init_TofsenseCascade_nodes()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::netlink_msg::msg::TofsenseCascade nodes(::netlink_msg::msg::TofsenseCascade::_nodes_type arg)
  {
    msg_.nodes = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseCascade msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::TofsenseCascade>()
{
  return netlink_msg::msg::builder::Init_TofsenseCascade_nodes();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__BUILDER_HPP_
