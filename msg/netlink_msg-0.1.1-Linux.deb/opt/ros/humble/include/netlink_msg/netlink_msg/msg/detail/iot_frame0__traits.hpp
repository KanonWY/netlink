// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from netlink_msg:msg/IotFrame0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__IOT_FRAME0__TRAITS_HPP_
#define NETLINK_MSG__MSG__DETAIL__IOT_FRAME0__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "netlink_msg/msg/detail/iot_frame0__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/iot_frame0_node__traits.hpp"

namespace netlink_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const IotFrame0 & msg,
  std::ostream & out)
{
  out << "{";
  // member: uid
  {
    out << "uid: ";
    rosidl_generator_traits::value_to_yaml(msg.uid, out);
    out << ", ";
  }

  // member: system_time
  {
    out << "system_time: ";
    rosidl_generator_traits::value_to_yaml(msg.system_time, out);
    out << ", ";
  }

  // member: io_status
  {
    out << "io_status: ";
    rosidl_generator_traits::value_to_yaml(msg.io_status, out);
    out << ", ";
  }

  // member: nodes
  {
    if (msg.nodes.size() == 0) {
      out << "nodes: []";
    } else {
      out << "nodes: [";
      size_t pending_items = msg.nodes.size();
      for (auto item : msg.nodes) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const IotFrame0 & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: uid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "uid: ";
    rosidl_generator_traits::value_to_yaml(msg.uid, out);
    out << "\n";
  }

  // member: system_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "system_time: ";
    rosidl_generator_traits::value_to_yaml(msg.system_time, out);
    out << "\n";
  }

  // member: io_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "io_status: ";
    rosidl_generator_traits::value_to_yaml(msg.io_status, out);
    out << "\n";
  }

  // member: nodes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.nodes.size() == 0) {
      out << "nodes: []\n";
    } else {
      out << "nodes:\n";
      for (auto item : msg.nodes) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const IotFrame0 & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace netlink_msg

namespace rosidl_generator_traits
{

[[deprecated("use netlink_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const netlink_msg::msg::IotFrame0 & msg,
  std::ostream & out, size_t indentation = 0)
{
  netlink_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use netlink_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const netlink_msg::msg::IotFrame0 & msg)
{
  return netlink_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<netlink_msg::msg::IotFrame0>()
{
  return "netlink_msg::msg::IotFrame0";
}

template<>
inline const char * name<netlink_msg::msg::IotFrame0>()
{
  return "netlink_msg/msg/IotFrame0";
}

template<>
struct has_fixed_size<netlink_msg::msg::IotFrame0>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<netlink_msg::msg::IotFrame0>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<netlink_msg::msg::IotFrame0>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // NETLINK_MSG__MSG__DETAIL__IOT_FRAME0__TRAITS_HPP_
