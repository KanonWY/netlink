// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from netlink_msg:msg/LinktrackAnchorframe0.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "netlink_msg/msg/detail/linktrack_anchorframe0__rosidl_typesupport_introspection_c.h"
#include "netlink_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "netlink_msg/msg/detail/linktrack_anchorframe0__functions.h"
#include "netlink_msg/msg/detail/linktrack_anchorframe0__struct.h"


// Include directives for member types
// Member `nodes`
#include "netlink_msg/msg/linktrack_tag.h"
// Member `nodes`
#include "netlink_msg/msg/detail/linktrack_tag__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  netlink_msg__msg__LinktrackAnchorframe0__init(message_memory);
}

void netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_fini_function(void * message_memory)
{
  netlink_msg__msg__LinktrackAnchorframe0__fini(message_memory);
}

size_t netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__size_function__LinktrackAnchorframe0__nodes(
  const void * untyped_member)
{
  const netlink_msg__msg__LinktrackTag__Sequence * member =
    (const netlink_msg__msg__LinktrackTag__Sequence *)(untyped_member);
  return member->size;
}

const void * netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__get_const_function__LinktrackAnchorframe0__nodes(
  const void * untyped_member, size_t index)
{
  const netlink_msg__msg__LinktrackTag__Sequence * member =
    (const netlink_msg__msg__LinktrackTag__Sequence *)(untyped_member);
  return &member->data[index];
}

void * netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__get_function__LinktrackAnchorframe0__nodes(
  void * untyped_member, size_t index)
{
  netlink_msg__msg__LinktrackTag__Sequence * member =
    (netlink_msg__msg__LinktrackTag__Sequence *)(untyped_member);
  return &member->data[index];
}

void netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__fetch_function__LinktrackAnchorframe0__nodes(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const netlink_msg__msg__LinktrackTag * item =
    ((const netlink_msg__msg__LinktrackTag *)
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__get_const_function__LinktrackAnchorframe0__nodes(untyped_member, index));
  netlink_msg__msg__LinktrackTag * value =
    (netlink_msg__msg__LinktrackTag *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__assign_function__LinktrackAnchorframe0__nodes(
  void * untyped_member, size_t index, const void * untyped_value)
{
  netlink_msg__msg__LinktrackTag * item =
    ((netlink_msg__msg__LinktrackTag *)
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__get_function__LinktrackAnchorframe0__nodes(untyped_member, index));
  const netlink_msg__msg__LinktrackTag * value =
    (const netlink_msg__msg__LinktrackTag *)(untyped_value);
  *item = *value;
}

bool netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__resize_function__LinktrackAnchorframe0__nodes(
  void * untyped_member, size_t size)
{
  netlink_msg__msg__LinktrackTag__Sequence * member =
    (netlink_msg__msg__LinktrackTag__Sequence *)(untyped_member);
  netlink_msg__msg__LinktrackTag__Sequence__fini(member);
  return netlink_msg__msg__LinktrackTag__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_member_array[6] = {
  {
    "role",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackAnchorframe0, role),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackAnchorframe0, id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "local_time",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackAnchorframe0, local_time),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "system_time",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackAnchorframe0, system_time),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "voltage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackAnchorframe0, voltage),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "nodes",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackAnchorframe0, nodes),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__size_function__LinktrackAnchorframe0__nodes,  // size() function pointer
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__get_const_function__LinktrackAnchorframe0__nodes,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__get_function__LinktrackAnchorframe0__nodes,  // get(index) function pointer
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__fetch_function__LinktrackAnchorframe0__nodes,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__assign_function__LinktrackAnchorframe0__nodes,  // assign(index, value) function pointer
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__resize_function__LinktrackAnchorframe0__nodes  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_members = {
  "netlink_msg__msg",  // message namespace
  "LinktrackAnchorframe0",  // message name
  6,  // number of fields
  sizeof(netlink_msg__msg__LinktrackAnchorframe0),
  netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_member_array,  // message members
  netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_init_function,  // function to initialize message memory (memory has to be allocated)
  netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_type_support_handle = {
  0,
  &netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_netlink_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, netlink_msg, msg, LinktrackAnchorframe0)() {
  netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, netlink_msg, msg, LinktrackTag)();
  if (!netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_type_support_handle.typesupport_identifier) {
    netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &netlink_msg__msg__LinktrackAnchorframe0__rosidl_typesupport_introspection_c__LinktrackAnchorframe0_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
