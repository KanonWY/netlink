// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackNode2.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE2__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE2__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_node2__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackNode2_rx_rssi
{
public:
  explicit Init_LinktrackNode2_rx_rssi(::netlink_msg::msg::LinktrackNode2 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackNode2 rx_rssi(::netlink_msg::msg::LinktrackNode2::_rx_rssi_type arg)
  {
    msg_.rx_rssi = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode2 msg_;
};

class Init_LinktrackNode2_fp_rssi
{
public:
  explicit Init_LinktrackNode2_fp_rssi(::netlink_msg::msg::LinktrackNode2 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNode2_rx_rssi fp_rssi(::netlink_msg::msg::LinktrackNode2::_fp_rssi_type arg)
  {
    msg_.fp_rssi = std::move(arg);
    return Init_LinktrackNode2_rx_rssi(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode2 msg_;
};

class Init_LinktrackNode2_dis
{
public:
  explicit Init_LinktrackNode2_dis(::netlink_msg::msg::LinktrackNode2 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNode2_fp_rssi dis(::netlink_msg::msg::LinktrackNode2::_dis_type arg)
  {
    msg_.dis = std::move(arg);
    return Init_LinktrackNode2_fp_rssi(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode2 msg_;
};

class Init_LinktrackNode2_id
{
public:
  explicit Init_LinktrackNode2_id(::netlink_msg::msg::LinktrackNode2 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNode2_dis id(::netlink_msg::msg::LinktrackNode2::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackNode2_dis(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode2 msg_;
};

class Init_LinktrackNode2_role
{
public:
  Init_LinktrackNode2_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackNode2_id role(::netlink_msg::msg::LinktrackNode2::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackNode2_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode2 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackNode2>()
{
  return netlink_msg::msg::builder::Init_LinktrackNode2_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE2__BUILDER_HPP_
