// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/IotFrame0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__IOT_FRAME0__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__IOT_FRAME0__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/iot_frame0__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_IotFrame0_nodes
{
public:
  explicit Init_IotFrame0_nodes(::netlink_msg::msg::IotFrame0 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::IotFrame0 nodes(::netlink_msg::msg::IotFrame0::_nodes_type arg)
  {
    msg_.nodes = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0 msg_;
};

class Init_IotFrame0_io_status
{
public:
  explicit Init_IotFrame0_io_status(::netlink_msg::msg::IotFrame0 & msg)
  : msg_(msg)
  {}
  Init_IotFrame0_nodes io_status(::netlink_msg::msg::IotFrame0::_io_status_type arg)
  {
    msg_.io_status = std::move(arg);
    return Init_IotFrame0_nodes(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0 msg_;
};

class Init_IotFrame0_system_time
{
public:
  explicit Init_IotFrame0_system_time(::netlink_msg::msg::IotFrame0 & msg)
  : msg_(msg)
  {}
  Init_IotFrame0_io_status system_time(::netlink_msg::msg::IotFrame0::_system_time_type arg)
  {
    msg_.system_time = std::move(arg);
    return Init_IotFrame0_io_status(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0 msg_;
};

class Init_IotFrame0_uid
{
public:
  Init_IotFrame0_uid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_IotFrame0_system_time uid(::netlink_msg::msg::IotFrame0::_uid_type arg)
  {
    msg_.uid = std::move(arg);
    return Init_IotFrame0_system_time(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::IotFrame0>()
{
  return netlink_msg::msg::builder::Init_IotFrame0_uid();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__IOT_FRAME0__BUILDER_HPP_
