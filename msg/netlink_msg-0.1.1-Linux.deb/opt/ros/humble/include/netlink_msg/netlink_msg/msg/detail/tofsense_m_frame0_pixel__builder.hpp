// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/TofsenseMFrame0Pixel.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0_PIXEL__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0_PIXEL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/tofsense_m_frame0_pixel__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_TofsenseMFrame0Pixel_signal_strength
{
public:
  explicit Init_TofsenseMFrame0Pixel_signal_strength(::netlink_msg::msg::TofsenseMFrame0Pixel & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::TofsenseMFrame0Pixel signal_strength(::netlink_msg::msg::TofsenseMFrame0Pixel::_signal_strength_type arg)
  {
    msg_.signal_strength = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseMFrame0Pixel msg_;
};

class Init_TofsenseMFrame0Pixel_dis_status
{
public:
  explicit Init_TofsenseMFrame0Pixel_dis_status(::netlink_msg::msg::TofsenseMFrame0Pixel & msg)
  : msg_(msg)
  {}
  Init_TofsenseMFrame0Pixel_signal_strength dis_status(::netlink_msg::msg::TofsenseMFrame0Pixel::_dis_status_type arg)
  {
    msg_.dis_status = std::move(arg);
    return Init_TofsenseMFrame0Pixel_signal_strength(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseMFrame0Pixel msg_;
};

class Init_TofsenseMFrame0Pixel_dis
{
public:
  Init_TofsenseMFrame0Pixel_dis()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TofsenseMFrame0Pixel_dis_status dis(::netlink_msg::msg::TofsenseMFrame0Pixel::_dis_type arg)
  {
    msg_.dis = std::move(arg);
    return Init_TofsenseMFrame0Pixel_dis_status(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseMFrame0Pixel msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::TofsenseMFrame0Pixel>()
{
  return netlink_msg::msg::builder::Init_TofsenseMFrame0Pixel_dis();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0_PIXEL__BUILDER_HPP_
