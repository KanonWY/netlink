// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__LINKTRACK_NODE5_HPP_
#define NETLINK_MSG__MSG__LINKTRACK_NODE5_HPP_

#include "netlink_msg/msg/detail/linktrack_node5__struct.hpp"
#include "netlink_msg/msg/detail/linktrack_node5__builder.hpp"
#include "netlink_msg/msg/detail/linktrack_node5__traits.hpp"

#endif  // NETLINK_MSG__MSG__LINKTRACK_NODE5_HPP_
