// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from netlink_msg:msg/LinktrackNode4Anchor.idl
// generated code does not contain a copyright notice
#include "netlink_msg/msg/detail/linktrack_node4_anchor__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
netlink_msg__msg__LinktrackNode4Anchor__init(netlink_msg__msg__LinktrackNode4Anchor * msg)
{
  if (!msg) {
    return false;
  }
  // id
  // dis
  return true;
}

void
netlink_msg__msg__LinktrackNode4Anchor__fini(netlink_msg__msg__LinktrackNode4Anchor * msg)
{
  if (!msg) {
    return;
  }
  // id
  // dis
}

bool
netlink_msg__msg__LinktrackNode4Anchor__are_equal(const netlink_msg__msg__LinktrackNode4Anchor * lhs, const netlink_msg__msg__LinktrackNode4Anchor * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // id
  if (lhs->id != rhs->id) {
    return false;
  }
  // dis
  if (lhs->dis != rhs->dis) {
    return false;
  }
  return true;
}

bool
netlink_msg__msg__LinktrackNode4Anchor__copy(
  const netlink_msg__msg__LinktrackNode4Anchor * input,
  netlink_msg__msg__LinktrackNode4Anchor * output)
{
  if (!input || !output) {
    return false;
  }
  // id
  output->id = input->id;
  // dis
  output->dis = input->dis;
  return true;
}

netlink_msg__msg__LinktrackNode4Anchor *
netlink_msg__msg__LinktrackNode4Anchor__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__LinktrackNode4Anchor * msg = (netlink_msg__msg__LinktrackNode4Anchor *)allocator.allocate(sizeof(netlink_msg__msg__LinktrackNode4Anchor), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(netlink_msg__msg__LinktrackNode4Anchor));
  bool success = netlink_msg__msg__LinktrackNode4Anchor__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
netlink_msg__msg__LinktrackNode4Anchor__destroy(netlink_msg__msg__LinktrackNode4Anchor * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    netlink_msg__msg__LinktrackNode4Anchor__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
netlink_msg__msg__LinktrackNode4Anchor__Sequence__init(netlink_msg__msg__LinktrackNode4Anchor__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__LinktrackNode4Anchor * data = NULL;

  if (size) {
    data = (netlink_msg__msg__LinktrackNode4Anchor *)allocator.zero_allocate(size, sizeof(netlink_msg__msg__LinktrackNode4Anchor), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = netlink_msg__msg__LinktrackNode4Anchor__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        netlink_msg__msg__LinktrackNode4Anchor__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
netlink_msg__msg__LinktrackNode4Anchor__Sequence__fini(netlink_msg__msg__LinktrackNode4Anchor__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      netlink_msg__msg__LinktrackNode4Anchor__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

netlink_msg__msg__LinktrackNode4Anchor__Sequence *
netlink_msg__msg__LinktrackNode4Anchor__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__LinktrackNode4Anchor__Sequence * array = (netlink_msg__msg__LinktrackNode4Anchor__Sequence *)allocator.allocate(sizeof(netlink_msg__msg__LinktrackNode4Anchor__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = netlink_msg__msg__LinktrackNode4Anchor__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
netlink_msg__msg__LinktrackNode4Anchor__Sequence__destroy(netlink_msg__msg__LinktrackNode4Anchor__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    netlink_msg__msg__LinktrackNode4Anchor__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
netlink_msg__msg__LinktrackNode4Anchor__Sequence__are_equal(const netlink_msg__msg__LinktrackNode4Anchor__Sequence * lhs, const netlink_msg__msg__LinktrackNode4Anchor__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!netlink_msg__msg__LinktrackNode4Anchor__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
netlink_msg__msg__LinktrackNode4Anchor__Sequence__copy(
  const netlink_msg__msg__LinktrackNode4Anchor__Sequence * input,
  netlink_msg__msg__LinktrackNode4Anchor__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(netlink_msg__msg__LinktrackNode4Anchor);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    netlink_msg__msg__LinktrackNode4Anchor * data =
      (netlink_msg__msg__LinktrackNode4Anchor *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!netlink_msg__msg__LinktrackNode4Anchor__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          netlink_msg__msg__LinktrackNode4Anchor__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!netlink_msg__msg__LinktrackNode4Anchor__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
