// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackNodeframe3.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME3__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME3__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_nodeframe3__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackNodeframe3_nodes
{
public:
  explicit Init_LinktrackNodeframe3_nodes(::netlink_msg::msg::LinktrackNodeframe3 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackNodeframe3 nodes(::netlink_msg::msg::LinktrackNodeframe3::_nodes_type arg)
  {
    msg_.nodes = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe3 msg_;
};

class Init_LinktrackNodeframe3_voltage
{
public:
  explicit Init_LinktrackNodeframe3_voltage(::netlink_msg::msg::LinktrackNodeframe3 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNodeframe3_nodes voltage(::netlink_msg::msg::LinktrackNodeframe3::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_LinktrackNodeframe3_nodes(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe3 msg_;
};

class Init_LinktrackNodeframe3_system_time
{
public:
  explicit Init_LinktrackNodeframe3_system_time(::netlink_msg::msg::LinktrackNodeframe3 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNodeframe3_voltage system_time(::netlink_msg::msg::LinktrackNodeframe3::_system_time_type arg)
  {
    msg_.system_time = std::move(arg);
    return Init_LinktrackNodeframe3_voltage(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe3 msg_;
};

class Init_LinktrackNodeframe3_local_time
{
public:
  explicit Init_LinktrackNodeframe3_local_time(::netlink_msg::msg::LinktrackNodeframe3 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNodeframe3_system_time local_time(::netlink_msg::msg::LinktrackNodeframe3::_local_time_type arg)
  {
    msg_.local_time = std::move(arg);
    return Init_LinktrackNodeframe3_system_time(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe3 msg_;
};

class Init_LinktrackNodeframe3_id
{
public:
  explicit Init_LinktrackNodeframe3_id(::netlink_msg::msg::LinktrackNodeframe3 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNodeframe3_local_time id(::netlink_msg::msg::LinktrackNodeframe3::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackNodeframe3_local_time(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe3 msg_;
};

class Init_LinktrackNodeframe3_role
{
public:
  Init_LinktrackNodeframe3_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackNodeframe3_id role(::netlink_msg::msg::LinktrackNodeframe3::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackNodeframe3_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe3 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackNodeframe3>()
{
  return netlink_msg::msg::builder::Init_LinktrackNodeframe3_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME3__BUILDER_HPP_
