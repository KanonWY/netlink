// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/TofsenseFrame0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__TOFSENSE_FRAME0__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__TOFSENSE_FRAME0__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/tofsense_frame0__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_TofsenseFrame0_range_precision
{
public:
  explicit Init_TofsenseFrame0_range_precision(::netlink_msg::msg::TofsenseFrame0 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::TofsenseFrame0 range_precision(::netlink_msg::msg::TofsenseFrame0::_range_precision_type arg)
  {
    msg_.range_precision = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseFrame0 msg_;
};

class Init_TofsenseFrame0_signal_strength
{
public:
  explicit Init_TofsenseFrame0_signal_strength(::netlink_msg::msg::TofsenseFrame0 & msg)
  : msg_(msg)
  {}
  Init_TofsenseFrame0_range_precision signal_strength(::netlink_msg::msg::TofsenseFrame0::_signal_strength_type arg)
  {
    msg_.signal_strength = std::move(arg);
    return Init_TofsenseFrame0_range_precision(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseFrame0 msg_;
};

class Init_TofsenseFrame0_dis_status
{
public:
  explicit Init_TofsenseFrame0_dis_status(::netlink_msg::msg::TofsenseFrame0 & msg)
  : msg_(msg)
  {}
  Init_TofsenseFrame0_signal_strength dis_status(::netlink_msg::msg::TofsenseFrame0::_dis_status_type arg)
  {
    msg_.dis_status = std::move(arg);
    return Init_TofsenseFrame0_signal_strength(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseFrame0 msg_;
};

class Init_TofsenseFrame0_dis
{
public:
  explicit Init_TofsenseFrame0_dis(::netlink_msg::msg::TofsenseFrame0 & msg)
  : msg_(msg)
  {}
  Init_TofsenseFrame0_dis_status dis(::netlink_msg::msg::TofsenseFrame0::_dis_type arg)
  {
    msg_.dis = std::move(arg);
    return Init_TofsenseFrame0_dis_status(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseFrame0 msg_;
};

class Init_TofsenseFrame0_system_time
{
public:
  explicit Init_TofsenseFrame0_system_time(::netlink_msg::msg::TofsenseFrame0 & msg)
  : msg_(msg)
  {}
  Init_TofsenseFrame0_dis system_time(::netlink_msg::msg::TofsenseFrame0::_system_time_type arg)
  {
    msg_.system_time = std::move(arg);
    return Init_TofsenseFrame0_dis(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseFrame0 msg_;
};

class Init_TofsenseFrame0_id
{
public:
  Init_TofsenseFrame0_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TofsenseFrame0_system_time id(::netlink_msg::msg::TofsenseFrame0::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_TofsenseFrame0_system_time(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseFrame0 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::TofsenseFrame0>()
{
  return netlink_msg::msg::builder::Init_TofsenseFrame0_id();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__TOFSENSE_FRAME0__BUILDER_HPP_
