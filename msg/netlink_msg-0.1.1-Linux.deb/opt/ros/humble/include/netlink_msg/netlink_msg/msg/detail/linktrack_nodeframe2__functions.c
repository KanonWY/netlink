// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from netlink_msg:msg/LinktrackNodeframe2.idl
// generated code does not contain a copyright notice
#include "netlink_msg/msg/detail/linktrack_nodeframe2__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `nodes`
#include "netlink_msg/msg/detail/linktrack_node2__functions.h"

bool
netlink_msg__msg__LinktrackNodeframe2__init(netlink_msg__msg__LinktrackNodeframe2 * msg)
{
  if (!msg) {
    return false;
  }
  // role
  // id
  // local_time
  // system_time
  // voltage
  // pos_3d
  // eop_3d
  // vel_3d
  // angle_3d
  // quaternion
  // imu_gyro_3d
  // imu_acc_3d
  // nodes
  if (!netlink_msg__msg__LinktrackNode2__Sequence__init(&msg->nodes, 0)) {
    netlink_msg__msg__LinktrackNodeframe2__fini(msg);
    return false;
  }
  return true;
}

void
netlink_msg__msg__LinktrackNodeframe2__fini(netlink_msg__msg__LinktrackNodeframe2 * msg)
{
  if (!msg) {
    return;
  }
  // role
  // id
  // local_time
  // system_time
  // voltage
  // pos_3d
  // eop_3d
  // vel_3d
  // angle_3d
  // quaternion
  // imu_gyro_3d
  // imu_acc_3d
  // nodes
  netlink_msg__msg__LinktrackNode2__Sequence__fini(&msg->nodes);
}

bool
netlink_msg__msg__LinktrackNodeframe2__are_equal(const netlink_msg__msg__LinktrackNodeframe2 * lhs, const netlink_msg__msg__LinktrackNodeframe2 * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // role
  if (lhs->role != rhs->role) {
    return false;
  }
  // id
  if (lhs->id != rhs->id) {
    return false;
  }
  // local_time
  if (lhs->local_time != rhs->local_time) {
    return false;
  }
  // system_time
  if (lhs->system_time != rhs->system_time) {
    return false;
  }
  // voltage
  if (lhs->voltage != rhs->voltage) {
    return false;
  }
  // pos_3d
  for (size_t i = 0; i < 3; ++i) {
    if (lhs->pos_3d[i] != rhs->pos_3d[i]) {
      return false;
    }
  }
  // eop_3d
  for (size_t i = 0; i < 3; ++i) {
    if (lhs->eop_3d[i] != rhs->eop_3d[i]) {
      return false;
    }
  }
  // vel_3d
  for (size_t i = 0; i < 3; ++i) {
    if (lhs->vel_3d[i] != rhs->vel_3d[i]) {
      return false;
    }
  }
  // angle_3d
  for (size_t i = 0; i < 3; ++i) {
    if (lhs->angle_3d[i] != rhs->angle_3d[i]) {
      return false;
    }
  }
  // quaternion
  for (size_t i = 0; i < 4; ++i) {
    if (lhs->quaternion[i] != rhs->quaternion[i]) {
      return false;
    }
  }
  // imu_gyro_3d
  for (size_t i = 0; i < 3; ++i) {
    if (lhs->imu_gyro_3d[i] != rhs->imu_gyro_3d[i]) {
      return false;
    }
  }
  // imu_acc_3d
  for (size_t i = 0; i < 3; ++i) {
    if (lhs->imu_acc_3d[i] != rhs->imu_acc_3d[i]) {
      return false;
    }
  }
  // nodes
  if (!netlink_msg__msg__LinktrackNode2__Sequence__are_equal(
      &(lhs->nodes), &(rhs->nodes)))
  {
    return false;
  }
  return true;
}

bool
netlink_msg__msg__LinktrackNodeframe2__copy(
  const netlink_msg__msg__LinktrackNodeframe2 * input,
  netlink_msg__msg__LinktrackNodeframe2 * output)
{
  if (!input || !output) {
    return false;
  }
  // role
  output->role = input->role;
  // id
  output->id = input->id;
  // local_time
  output->local_time = input->local_time;
  // system_time
  output->system_time = input->system_time;
  // voltage
  output->voltage = input->voltage;
  // pos_3d
  for (size_t i = 0; i < 3; ++i) {
    output->pos_3d[i] = input->pos_3d[i];
  }
  // eop_3d
  for (size_t i = 0; i < 3; ++i) {
    output->eop_3d[i] = input->eop_3d[i];
  }
  // vel_3d
  for (size_t i = 0; i < 3; ++i) {
    output->vel_3d[i] = input->vel_3d[i];
  }
  // angle_3d
  for (size_t i = 0; i < 3; ++i) {
    output->angle_3d[i] = input->angle_3d[i];
  }
  // quaternion
  for (size_t i = 0; i < 4; ++i) {
    output->quaternion[i] = input->quaternion[i];
  }
  // imu_gyro_3d
  for (size_t i = 0; i < 3; ++i) {
    output->imu_gyro_3d[i] = input->imu_gyro_3d[i];
  }
  // imu_acc_3d
  for (size_t i = 0; i < 3; ++i) {
    output->imu_acc_3d[i] = input->imu_acc_3d[i];
  }
  // nodes
  if (!netlink_msg__msg__LinktrackNode2__Sequence__copy(
      &(input->nodes), &(output->nodes)))
  {
    return false;
  }
  return true;
}

netlink_msg__msg__LinktrackNodeframe2 *
netlink_msg__msg__LinktrackNodeframe2__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__LinktrackNodeframe2 * msg = (netlink_msg__msg__LinktrackNodeframe2 *)allocator.allocate(sizeof(netlink_msg__msg__LinktrackNodeframe2), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(netlink_msg__msg__LinktrackNodeframe2));
  bool success = netlink_msg__msg__LinktrackNodeframe2__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
netlink_msg__msg__LinktrackNodeframe2__destroy(netlink_msg__msg__LinktrackNodeframe2 * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    netlink_msg__msg__LinktrackNodeframe2__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
netlink_msg__msg__LinktrackNodeframe2__Sequence__init(netlink_msg__msg__LinktrackNodeframe2__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__LinktrackNodeframe2 * data = NULL;

  if (size) {
    data = (netlink_msg__msg__LinktrackNodeframe2 *)allocator.zero_allocate(size, sizeof(netlink_msg__msg__LinktrackNodeframe2), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = netlink_msg__msg__LinktrackNodeframe2__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        netlink_msg__msg__LinktrackNodeframe2__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
netlink_msg__msg__LinktrackNodeframe2__Sequence__fini(netlink_msg__msg__LinktrackNodeframe2__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      netlink_msg__msg__LinktrackNodeframe2__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

netlink_msg__msg__LinktrackNodeframe2__Sequence *
netlink_msg__msg__LinktrackNodeframe2__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__LinktrackNodeframe2__Sequence * array = (netlink_msg__msg__LinktrackNodeframe2__Sequence *)allocator.allocate(sizeof(netlink_msg__msg__LinktrackNodeframe2__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = netlink_msg__msg__LinktrackNodeframe2__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
netlink_msg__msg__LinktrackNodeframe2__Sequence__destroy(netlink_msg__msg__LinktrackNodeframe2__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    netlink_msg__msg__LinktrackNodeframe2__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
netlink_msg__msg__LinktrackNodeframe2__Sequence__are_equal(const netlink_msg__msg__LinktrackNodeframe2__Sequence * lhs, const netlink_msg__msg__LinktrackNodeframe2__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!netlink_msg__msg__LinktrackNodeframe2__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
netlink_msg__msg__LinktrackNodeframe2__Sequence__copy(
  const netlink_msg__msg__LinktrackNodeframe2__Sequence * input,
  netlink_msg__msg__LinktrackNodeframe2__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(netlink_msg__msg__LinktrackNodeframe2);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    netlink_msg__msg__LinktrackNodeframe2 * data =
      (netlink_msg__msg__LinktrackNodeframe2 *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!netlink_msg__msg__LinktrackNodeframe2__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          netlink_msg__msg__LinktrackNodeframe2__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!netlink_msg__msg__LinktrackNodeframe2__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
