// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from netlink_msg:msg/TofsenseCascade.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__TRAITS_HPP_
#define NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "netlink_msg/msg/detail/tofsense_cascade__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/tofsense_frame0__traits.hpp"

namespace netlink_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const TofsenseCascade & msg,
  std::ostream & out)
{
  out << "{";
  // member: nodes
  {
    if (msg.nodes.size() == 0) {
      out << "nodes: []";
    } else {
      out << "nodes: [";
      size_t pending_items = msg.nodes.size();
      for (auto item : msg.nodes) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const TofsenseCascade & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: nodes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.nodes.size() == 0) {
      out << "nodes: []\n";
    } else {
      out << "nodes:\n";
      for (auto item : msg.nodes) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const TofsenseCascade & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace netlink_msg

namespace rosidl_generator_traits
{

[[deprecated("use netlink_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const netlink_msg::msg::TofsenseCascade & msg,
  std::ostream & out, size_t indentation = 0)
{
  netlink_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use netlink_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const netlink_msg::msg::TofsenseCascade & msg)
{
  return netlink_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<netlink_msg::msg::TofsenseCascade>()
{
  return "netlink_msg::msg::TofsenseCascade";
}

template<>
inline const char * name<netlink_msg::msg::TofsenseCascade>()
{
  return "netlink_msg/msg/TofsenseCascade";
}

template<>
struct has_fixed_size<netlink_msg::msg::TofsenseCascade>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<netlink_msg::msg::TofsenseCascade>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<netlink_msg::msg::TofsenseCascade>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__TRAITS_HPP_
