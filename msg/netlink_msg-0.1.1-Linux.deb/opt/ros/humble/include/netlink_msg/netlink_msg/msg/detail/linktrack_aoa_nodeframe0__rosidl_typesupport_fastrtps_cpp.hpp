// generated from rosidl_typesupport_fastrtps_cpp/resource/idl__rosidl_typesupport_fastrtps_cpp.hpp.em
// with input from netlink_msg:msg/LinktrackAoaNodeframe0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "netlink_msg/msg/rosidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "netlink_msg/msg/detail/linktrack_aoa_nodeframe0__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace netlink_msg
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_netlink_msg
cdr_serialize(
  const netlink_msg::msg::LinktrackAoaNodeframe0 & ros_message,
  eprosima::fastcdr::Cdr & cdr);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_netlink_msg
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  netlink_msg::msg::LinktrackAoaNodeframe0 & ros_message);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_netlink_msg
get_serialized_size(
  const netlink_msg::msg::LinktrackAoaNodeframe0 & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_netlink_msg
max_serialized_size_LinktrackAoaNodeframe0(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace netlink_msg

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_netlink_msg
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_cpp, netlink_msg, msg, LinktrackAoaNodeframe0)();

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
