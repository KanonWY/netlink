// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from netlink_msg:msg/LinktrackNodeframe2.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME2__TRAITS_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME2__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "netlink_msg/msg/detail/linktrack_nodeframe2__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/linktrack_node2__traits.hpp"

namespace netlink_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const LinktrackNodeframe2 & msg,
  std::ostream & out)
{
  out << "{";
  // member: role
  {
    out << "role: ";
    rosidl_generator_traits::value_to_yaml(msg.role, out);
    out << ", ";
  }

  // member: id
  {
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << ", ";
  }

  // member: local_time
  {
    out << "local_time: ";
    rosidl_generator_traits::value_to_yaml(msg.local_time, out);
    out << ", ";
  }

  // member: system_time
  {
    out << "system_time: ";
    rosidl_generator_traits::value_to_yaml(msg.system_time, out);
    out << ", ";
  }

  // member: voltage
  {
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
    out << ", ";
  }

  // member: pos_3d
  {
    if (msg.pos_3d.size() == 0) {
      out << "pos_3d: []";
    } else {
      out << "pos_3d: [";
      size_t pending_items = msg.pos_3d.size();
      for (auto item : msg.pos_3d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: eop_3d
  {
    if (msg.eop_3d.size() == 0) {
      out << "eop_3d: []";
    } else {
      out << "eop_3d: [";
      size_t pending_items = msg.eop_3d.size();
      for (auto item : msg.eop_3d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: vel_3d
  {
    if (msg.vel_3d.size() == 0) {
      out << "vel_3d: []";
    } else {
      out << "vel_3d: [";
      size_t pending_items = msg.vel_3d.size();
      for (auto item : msg.vel_3d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: angle_3d
  {
    if (msg.angle_3d.size() == 0) {
      out << "angle_3d: []";
    } else {
      out << "angle_3d: [";
      size_t pending_items = msg.angle_3d.size();
      for (auto item : msg.angle_3d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: quaternion
  {
    if (msg.quaternion.size() == 0) {
      out << "quaternion: []";
    } else {
      out << "quaternion: [";
      size_t pending_items = msg.quaternion.size();
      for (auto item : msg.quaternion) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: imu_gyro_3d
  {
    if (msg.imu_gyro_3d.size() == 0) {
      out << "imu_gyro_3d: []";
    } else {
      out << "imu_gyro_3d: [";
      size_t pending_items = msg.imu_gyro_3d.size();
      for (auto item : msg.imu_gyro_3d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: imu_acc_3d
  {
    if (msg.imu_acc_3d.size() == 0) {
      out << "imu_acc_3d: []";
    } else {
      out << "imu_acc_3d: [";
      size_t pending_items = msg.imu_acc_3d.size();
      for (auto item : msg.imu_acc_3d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: nodes
  {
    if (msg.nodes.size() == 0) {
      out << "nodes: []";
    } else {
      out << "nodes: [";
      size_t pending_items = msg.nodes.size();
      for (auto item : msg.nodes) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const LinktrackNodeframe2 & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: role
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "role: ";
    rosidl_generator_traits::value_to_yaml(msg.role, out);
    out << "\n";
  }

  // member: id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << "\n";
  }

  // member: local_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "local_time: ";
    rosidl_generator_traits::value_to_yaml(msg.local_time, out);
    out << "\n";
  }

  // member: system_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "system_time: ";
    rosidl_generator_traits::value_to_yaml(msg.system_time, out);
    out << "\n";
  }

  // member: voltage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
    out << "\n";
  }

  // member: pos_3d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.pos_3d.size() == 0) {
      out << "pos_3d: []\n";
    } else {
      out << "pos_3d:\n";
      for (auto item : msg.pos_3d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: eop_3d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.eop_3d.size() == 0) {
      out << "eop_3d: []\n";
    } else {
      out << "eop_3d:\n";
      for (auto item : msg.eop_3d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: vel_3d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.vel_3d.size() == 0) {
      out << "vel_3d: []\n";
    } else {
      out << "vel_3d:\n";
      for (auto item : msg.vel_3d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: angle_3d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.angle_3d.size() == 0) {
      out << "angle_3d: []\n";
    } else {
      out << "angle_3d:\n";
      for (auto item : msg.angle_3d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: quaternion
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.quaternion.size() == 0) {
      out << "quaternion: []\n";
    } else {
      out << "quaternion:\n";
      for (auto item : msg.quaternion) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: imu_gyro_3d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.imu_gyro_3d.size() == 0) {
      out << "imu_gyro_3d: []\n";
    } else {
      out << "imu_gyro_3d:\n";
      for (auto item : msg.imu_gyro_3d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: imu_acc_3d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.imu_acc_3d.size() == 0) {
      out << "imu_acc_3d: []\n";
    } else {
      out << "imu_acc_3d:\n";
      for (auto item : msg.imu_acc_3d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: nodes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.nodes.size() == 0) {
      out << "nodes: []\n";
    } else {
      out << "nodes:\n";
      for (auto item : msg.nodes) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const LinktrackNodeframe2 & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace netlink_msg

namespace rosidl_generator_traits
{

[[deprecated("use netlink_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const netlink_msg::msg::LinktrackNodeframe2 & msg,
  std::ostream & out, size_t indentation = 0)
{
  netlink_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use netlink_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const netlink_msg::msg::LinktrackNodeframe2 & msg)
{
  return netlink_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<netlink_msg::msg::LinktrackNodeframe2>()
{
  return "netlink_msg::msg::LinktrackNodeframe2";
}

template<>
inline const char * name<netlink_msg::msg::LinktrackNodeframe2>()
{
  return "netlink_msg/msg/LinktrackNodeframe2";
}

template<>
struct has_fixed_size<netlink_msg::msg::LinktrackNodeframe2>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<netlink_msg::msg::LinktrackNodeframe2>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<netlink_msg::msg::LinktrackNodeframe2>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME2__TRAITS_HPP_
