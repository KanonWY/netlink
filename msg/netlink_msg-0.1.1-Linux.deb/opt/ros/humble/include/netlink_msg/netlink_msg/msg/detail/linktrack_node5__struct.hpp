// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from netlink_msg:msg/LinktrackNode5.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE5__STRUCT_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE5__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__netlink_msg__msg__LinktrackNode5 __attribute__((deprecated))
#else
# define DEPRECATED__netlink_msg__msg__LinktrackNode5 __declspec(deprecated)
#endif

namespace netlink_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LinktrackNode5_
{
  using Type = LinktrackNode5_<ContainerAllocator>;

  explicit LinktrackNode5_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->role = 0;
      this->id = 0ul;
      this->dis = 0.0f;
      this->fp_rssi = 0.0f;
      this->rx_rssi = 0.0f;
    }
  }

  explicit LinktrackNode5_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->role = 0;
      this->id = 0ul;
      this->dis = 0.0f;
      this->fp_rssi = 0.0f;
      this->rx_rssi = 0.0f;
    }
  }

  // field types and members
  using _role_type =
    uint8_t;
  _role_type role;
  using _id_type =
    uint32_t;
  _id_type id;
  using _dis_type =
    float;
  _dis_type dis;
  using _fp_rssi_type =
    float;
  _fp_rssi_type fp_rssi;
  using _rx_rssi_type =
    float;
  _rx_rssi_type rx_rssi;

  // setters for named parameter idiom
  Type & set__role(
    const uint8_t & _arg)
  {
    this->role = _arg;
    return *this;
  }
  Type & set__id(
    const uint32_t & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__dis(
    const float & _arg)
  {
    this->dis = _arg;
    return *this;
  }
  Type & set__fp_rssi(
    const float & _arg)
  {
    this->fp_rssi = _arg;
    return *this;
  }
  Type & set__rx_rssi(
    const float & _arg)
  {
    this->rx_rssi = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    netlink_msg::msg::LinktrackNode5_<ContainerAllocator> *;
  using ConstRawPtr =
    const netlink_msg::msg::LinktrackNode5_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::LinktrackNode5_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::LinktrackNode5_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__netlink_msg__msg__LinktrackNode5
    std::shared_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__netlink_msg__msg__LinktrackNode5
    std::shared_ptr<netlink_msg::msg::LinktrackNode5_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LinktrackNode5_ & other) const
  {
    if (this->role != other.role) {
      return false;
    }
    if (this->id != other.id) {
      return false;
    }
    if (this->dis != other.dis) {
      return false;
    }
    if (this->fp_rssi != other.fp_rssi) {
      return false;
    }
    if (this->rx_rssi != other.rx_rssi) {
      return false;
    }
    return true;
  }
  bool operator!=(const LinktrackNode5_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LinktrackNode5_

// alias to use template instance with default allocator
using LinktrackNode5 =
  netlink_msg::msg::LinktrackNode5_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE5__STRUCT_HPP_
