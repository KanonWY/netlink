// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/LinktrackNode0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE0__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE0__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'data'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/LinktrackNode0 in the package netlink_msg.
typedef struct netlink_msg__msg__LinktrackNode0
{
  uint8_t role;
  uint8_t id;
  rosidl_runtime_c__uint8__Sequence data;
} netlink_msg__msg__LinktrackNode0;

// Struct for a sequence of netlink_msg__msg__LinktrackNode0.
typedef struct netlink_msg__msg__LinktrackNode0__Sequence
{
  netlink_msg__msg__LinktrackNode0 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__LinktrackNode0__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE0__STRUCT_H_
