// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/LinktrackNode0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__LINKTRACK_NODE0_H_
#define NETLINK_MSG__MSG__LINKTRACK_NODE0_H_

#include "netlink_msg/msg/detail/linktrack_node0__struct.h"
#include "netlink_msg/msg/detail/linktrack_node0__functions.h"
#include "netlink_msg/msg/detail/linktrack_node0__type_support.h"

#endif  // NETLINK_MSG__MSG__LINKTRACK_NODE0_H_
