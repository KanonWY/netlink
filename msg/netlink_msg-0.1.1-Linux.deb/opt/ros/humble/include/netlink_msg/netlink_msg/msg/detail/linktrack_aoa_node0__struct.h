// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/LinktrackAoaNode0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/LinktrackAoaNode0 in the package netlink_msg.
typedef struct netlink_msg__msg__LinktrackAoaNode0
{
  uint8_t role;
  uint8_t id;
  float dis;
  float angle;
  float fp_rssi;
  float rx_rssi;
} netlink_msg__msg__LinktrackAoaNode0;

// Struct for a sequence of netlink_msg__msg__LinktrackAoaNode0.
typedef struct netlink_msg__msg__LinktrackAoaNode0__Sequence
{
  netlink_msg__msg__LinktrackAoaNode0 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__LinktrackAoaNode0__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__STRUCT_H_
