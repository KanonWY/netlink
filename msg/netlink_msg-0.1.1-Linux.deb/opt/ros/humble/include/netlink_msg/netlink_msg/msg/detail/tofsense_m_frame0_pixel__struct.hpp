// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from netlink_msg:msg/TofsenseMFrame0Pixel.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0_PIXEL__STRUCT_HPP_
#define NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0_PIXEL__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__netlink_msg__msg__TofsenseMFrame0Pixel __attribute__((deprecated))
#else
# define DEPRECATED__netlink_msg__msg__TofsenseMFrame0Pixel __declspec(deprecated)
#endif

namespace netlink_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct TofsenseMFrame0Pixel_
{
  using Type = TofsenseMFrame0Pixel_<ContainerAllocator>;

  explicit TofsenseMFrame0Pixel_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dis = 0.0f;
      this->dis_status = 0;
      this->signal_strength = 0;
    }
  }

  explicit TofsenseMFrame0Pixel_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dis = 0.0f;
      this->dis_status = 0;
      this->signal_strength = 0;
    }
  }

  // field types and members
  using _dis_type =
    float;
  _dis_type dis;
  using _dis_status_type =
    uint8_t;
  _dis_status_type dis_status;
  using _signal_strength_type =
    uint16_t;
  _signal_strength_type signal_strength;

  // setters for named parameter idiom
  Type & set__dis(
    const float & _arg)
  {
    this->dis = _arg;
    return *this;
  }
  Type & set__dis_status(
    const uint8_t & _arg)
  {
    this->dis_status = _arg;
    return *this;
  }
  Type & set__signal_strength(
    const uint16_t & _arg)
  {
    this->signal_strength = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator> *;
  using ConstRawPtr =
    const netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__netlink_msg__msg__TofsenseMFrame0Pixel
    std::shared_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__netlink_msg__msg__TofsenseMFrame0Pixel
    std::shared_ptr<netlink_msg::msg::TofsenseMFrame0Pixel_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TofsenseMFrame0Pixel_ & other) const
  {
    if (this->dis != other.dis) {
      return false;
    }
    if (this->dis_status != other.dis_status) {
      return false;
    }
    if (this->signal_strength != other.signal_strength) {
      return false;
    }
    return true;
  }
  bool operator!=(const TofsenseMFrame0Pixel_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TofsenseMFrame0Pixel_

// alias to use template instance with default allocator
using TofsenseMFrame0Pixel =
  netlink_msg::msg::TofsenseMFrame0Pixel_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0_PIXEL__STRUCT_HPP_
