// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackNode4Tag.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE4_TAG__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE4_TAG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_node4_tag__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackNode4Tag_anchors
{
public:
  explicit Init_LinktrackNode4Tag_anchors(::netlink_msg::msg::LinktrackNode4Tag & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackNode4Tag anchors(::netlink_msg::msg::LinktrackNode4Tag::_anchors_type arg)
  {
    msg_.anchors = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode4Tag msg_;
};

class Init_LinktrackNode4Tag_voltage
{
public:
  explicit Init_LinktrackNode4Tag_voltage(::netlink_msg::msg::LinktrackNode4Tag & msg)
  : msg_(msg)
  {}
  Init_LinktrackNode4Tag_anchors voltage(::netlink_msg::msg::LinktrackNode4Tag::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_LinktrackNode4Tag_anchors(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode4Tag msg_;
};

class Init_LinktrackNode4Tag_id
{
public:
  Init_LinktrackNode4Tag_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackNode4Tag_voltage id(::netlink_msg::msg::LinktrackNode4Tag::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackNode4Tag_voltage(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode4Tag msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackNode4Tag>()
{
  return netlink_msg::msg::builder::Init_LinktrackNode4Tag_id();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE4_TAG__BUILDER_HPP_
