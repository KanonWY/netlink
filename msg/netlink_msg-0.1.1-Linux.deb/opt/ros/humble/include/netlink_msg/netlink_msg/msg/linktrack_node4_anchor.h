// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/LinktrackNode4Anchor.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__LINKTRACK_NODE4_ANCHOR_H_
#define NETLINK_MSG__MSG__LINKTRACK_NODE4_ANCHOR_H_

#include "netlink_msg/msg/detail/linktrack_node4_anchor__struct.h"
#include "netlink_msg/msg/detail/linktrack_node4_anchor__functions.h"
#include "netlink_msg/msg/detail/linktrack_node4_anchor__type_support.h"

#endif  // NETLINK_MSG__MSG__LINKTRACK_NODE4_ANCHOR_H_
