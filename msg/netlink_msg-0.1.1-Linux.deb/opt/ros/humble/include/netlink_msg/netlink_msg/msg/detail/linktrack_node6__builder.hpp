// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackNode6.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE6__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE6__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_node6__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackNode6_data
{
public:
  explicit Init_LinktrackNode6_data(::netlink_msg::msg::LinktrackNode6 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackNode6 data(::netlink_msg::msg::LinktrackNode6::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode6 msg_;
};

class Init_LinktrackNode6_id
{
public:
  explicit Init_LinktrackNode6_id(::netlink_msg::msg::LinktrackNode6 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNode6_data id(::netlink_msg::msg::LinktrackNode6::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackNode6_data(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode6 msg_;
};

class Init_LinktrackNode6_role
{
public:
  Init_LinktrackNode6_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackNode6_id role(::netlink_msg::msg::LinktrackNode6::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackNode6_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNode6 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackNode6>()
{
  return netlink_msg::msg::builder::Init_LinktrackNode6_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE6__BUILDER_HPP_
