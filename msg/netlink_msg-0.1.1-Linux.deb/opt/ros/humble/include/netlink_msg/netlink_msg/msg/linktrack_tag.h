// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/LinktrackTag.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__LINKTRACK_TAG_H_
#define NETLINK_MSG__MSG__LINKTRACK_TAG_H_

#include "netlink_msg/msg/detail/linktrack_tag__struct.h"
#include "netlink_msg/msg/detail/linktrack_tag__functions.h"
#include "netlink_msg/msg/detail/linktrack_tag__type_support.h"

#endif  // NETLINK_MSG__MSG__LINKTRACK_TAG_H_
