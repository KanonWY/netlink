// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__TOFSENSE_M_FRAME0_PIXEL_HPP_
#define NETLINK_MSG__MSG__TOFSENSE_M_FRAME0_PIXEL_HPP_

#include "netlink_msg/msg/detail/tofsense_m_frame0_pixel__struct.hpp"
#include "netlink_msg/msg/detail/tofsense_m_frame0_pixel__builder.hpp"
#include "netlink_msg/msg/detail/tofsense_m_frame0_pixel__traits.hpp"

#endif  // NETLINK_MSG__MSG__TOFSENSE_M_FRAME0_PIXEL_HPP_
