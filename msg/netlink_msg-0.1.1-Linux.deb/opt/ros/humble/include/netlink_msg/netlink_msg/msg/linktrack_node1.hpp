// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__LINKTRACK_NODE1_HPP_
#define NETLINK_MSG__MSG__LINKTRACK_NODE1_HPP_

#include "netlink_msg/msg/detail/linktrack_node1__struct.hpp"
#include "netlink_msg/msg/detail/linktrack_node1__builder.hpp"
#include "netlink_msg/msg/detail/linktrack_node1__traits.hpp"

#endif  // NETLINK_MSG__MSG__LINKTRACK_NODE1_HPP_
