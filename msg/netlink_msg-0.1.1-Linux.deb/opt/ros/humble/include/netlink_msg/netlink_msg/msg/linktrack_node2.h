// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/LinktrackNode2.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__LINKTRACK_NODE2_H_
#define NETLINK_MSG__MSG__LINKTRACK_NODE2_H_

#include "netlink_msg/msg/detail/linktrack_node2__struct.h"
#include "netlink_msg/msg/detail/linktrack_node2__functions.h"
#include "netlink_msg/msg/detail/linktrack_node2__type_support.h"

#endif  // NETLINK_MSG__MSG__LINKTRACK_NODE2_H_
