// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/LinktrackNodeframe3.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__LINKTRACK_NODEFRAME3_H_
#define NETLINK_MSG__MSG__LINKTRACK_NODEFRAME3_H_

#include "netlink_msg/msg/detail/linktrack_nodeframe3__struct.h"
#include "netlink_msg/msg/detail/linktrack_nodeframe3__functions.h"
#include "netlink_msg/msg/detail/linktrack_nodeframe3__type_support.h"

#endif  // NETLINK_MSG__MSG__LINKTRACK_NODEFRAME3_H_
