// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from netlink_msg:msg/TofsenseMFrame0.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "netlink_msg/msg/detail/tofsense_m_frame0__rosidl_typesupport_introspection_c.h"
#include "netlink_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "netlink_msg/msg/detail/tofsense_m_frame0__functions.h"
#include "netlink_msg/msg/detail/tofsense_m_frame0__struct.h"


// Include directives for member types
// Member `pixels`
#include "netlink_msg/msg/tofsense_m_frame0_pixel.h"
// Member `pixels`
#include "netlink_msg/msg/detail/tofsense_m_frame0_pixel__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  netlink_msg__msg__TofsenseMFrame0__init(message_memory);
}

void netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_fini_function(void * message_memory)
{
  netlink_msg__msg__TofsenseMFrame0__fini(message_memory);
}

size_t netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__size_function__TofsenseMFrame0__pixels(
  const void * untyped_member)
{
  const netlink_msg__msg__TofsenseMFrame0Pixel__Sequence * member =
    (const netlink_msg__msg__TofsenseMFrame0Pixel__Sequence *)(untyped_member);
  return member->size;
}

const void * netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__get_const_function__TofsenseMFrame0__pixels(
  const void * untyped_member, size_t index)
{
  const netlink_msg__msg__TofsenseMFrame0Pixel__Sequence * member =
    (const netlink_msg__msg__TofsenseMFrame0Pixel__Sequence *)(untyped_member);
  return &member->data[index];
}

void * netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__get_function__TofsenseMFrame0__pixels(
  void * untyped_member, size_t index)
{
  netlink_msg__msg__TofsenseMFrame0Pixel__Sequence * member =
    (netlink_msg__msg__TofsenseMFrame0Pixel__Sequence *)(untyped_member);
  return &member->data[index];
}

void netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__fetch_function__TofsenseMFrame0__pixels(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const netlink_msg__msg__TofsenseMFrame0Pixel * item =
    ((const netlink_msg__msg__TofsenseMFrame0Pixel *)
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__get_const_function__TofsenseMFrame0__pixels(untyped_member, index));
  netlink_msg__msg__TofsenseMFrame0Pixel * value =
    (netlink_msg__msg__TofsenseMFrame0Pixel *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__assign_function__TofsenseMFrame0__pixels(
  void * untyped_member, size_t index, const void * untyped_value)
{
  netlink_msg__msg__TofsenseMFrame0Pixel * item =
    ((netlink_msg__msg__TofsenseMFrame0Pixel *)
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__get_function__TofsenseMFrame0__pixels(untyped_member, index));
  const netlink_msg__msg__TofsenseMFrame0Pixel * value =
    (const netlink_msg__msg__TofsenseMFrame0Pixel *)(untyped_value);
  *item = *value;
}

bool netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__resize_function__TofsenseMFrame0__pixels(
  void * untyped_member, size_t size)
{
  netlink_msg__msg__TofsenseMFrame0Pixel__Sequence * member =
    (netlink_msg__msg__TofsenseMFrame0Pixel__Sequence *)(untyped_member);
  netlink_msg__msg__TofsenseMFrame0Pixel__Sequence__fini(member);
  return netlink_msg__msg__TofsenseMFrame0Pixel__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_member_array[4] = {
  {
    "id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__TofsenseMFrame0, id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "system_time",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__TofsenseMFrame0, system_time),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pixel_count",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__TofsenseMFrame0, pixel_count),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pixels",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__TofsenseMFrame0, pixels),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__size_function__TofsenseMFrame0__pixels,  // size() function pointer
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__get_const_function__TofsenseMFrame0__pixels,  // get_const(index) function pointer
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__get_function__TofsenseMFrame0__pixels,  // get(index) function pointer
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__fetch_function__TofsenseMFrame0__pixels,  // fetch(index, &value) function pointer
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__assign_function__TofsenseMFrame0__pixels,  // assign(index, value) function pointer
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__resize_function__TofsenseMFrame0__pixels  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_members = {
  "netlink_msg__msg",  // message namespace
  "TofsenseMFrame0",  // message name
  4,  // number of fields
  sizeof(netlink_msg__msg__TofsenseMFrame0),
  netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_member_array,  // message members
  netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_init_function,  // function to initialize message memory (memory has to be allocated)
  netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_type_support_handle = {
  0,
  &netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_netlink_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, netlink_msg, msg, TofsenseMFrame0)() {
  netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, netlink_msg, msg, TofsenseMFrame0Pixel)();
  if (!netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_type_support_handle.typesupport_identifier) {
    netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &netlink_msg__msg__TofsenseMFrame0__rosidl_typesupport_introspection_c__TofsenseMFrame0_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
