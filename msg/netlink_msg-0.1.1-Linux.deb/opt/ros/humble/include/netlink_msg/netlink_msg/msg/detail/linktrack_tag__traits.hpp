// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from netlink_msg:msg/LinktrackTag.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__TRAITS_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "netlink_msg/msg/detail/linktrack_tag__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace netlink_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const LinktrackTag & msg,
  std::ostream & out)
{
  out << "{";
  // member: role
  {
    out << "role: ";
    rosidl_generator_traits::value_to_yaml(msg.role, out);
    out << ", ";
  }

  // member: id
  {
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << ", ";
  }

  // member: pos_3d
  {
    if (msg.pos_3d.size() == 0) {
      out << "pos_3d: []";
    } else {
      out << "pos_3d: [";
      size_t pending_items = msg.pos_3d.size();
      for (auto item : msg.pos_3d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: dis_arr
  {
    if (msg.dis_arr.size() == 0) {
      out << "dis_arr: []";
    } else {
      out << "dis_arr: [";
      size_t pending_items = msg.dis_arr.size();
      for (auto item : msg.dis_arr) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const LinktrackTag & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: role
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "role: ";
    rosidl_generator_traits::value_to_yaml(msg.role, out);
    out << "\n";
  }

  // member: id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << "\n";
  }

  // member: pos_3d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.pos_3d.size() == 0) {
      out << "pos_3d: []\n";
    } else {
      out << "pos_3d:\n";
      for (auto item : msg.pos_3d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: dis_arr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.dis_arr.size() == 0) {
      out << "dis_arr: []\n";
    } else {
      out << "dis_arr:\n";
      for (auto item : msg.dis_arr) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const LinktrackTag & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace netlink_msg

namespace rosidl_generator_traits
{

[[deprecated("use netlink_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const netlink_msg::msg::LinktrackTag & msg,
  std::ostream & out, size_t indentation = 0)
{
  netlink_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use netlink_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const netlink_msg::msg::LinktrackTag & msg)
{
  return netlink_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<netlink_msg::msg::LinktrackTag>()
{
  return "netlink_msg::msg::LinktrackTag";
}

template<>
inline const char * name<netlink_msg::msg::LinktrackTag>()
{
  return "netlink_msg/msg/LinktrackTag";
}

template<>
struct has_fixed_size<netlink_msg::msg::LinktrackTag>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<netlink_msg::msg::LinktrackTag>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<netlink_msg::msg::LinktrackTag>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__TRAITS_HPP_
