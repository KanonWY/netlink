// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from netlink_msg:msg/LinktrackNodeframe2.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "netlink_msg/msg/detail/linktrack_nodeframe2__rosidl_typesupport_introspection_c.h"
#include "netlink_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "netlink_msg/msg/detail/linktrack_nodeframe2__functions.h"
#include "netlink_msg/msg/detail/linktrack_nodeframe2__struct.h"


// Include directives for member types
// Member `nodes`
#include "netlink_msg/msg/linktrack_node2.h"
// Member `nodes`
#include "netlink_msg/msg/detail/linktrack_node2__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  netlink_msg__msg__LinktrackNodeframe2__init(message_memory);
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_fini_function(void * message_memory)
{
  netlink_msg__msg__LinktrackNodeframe2__fini(message_memory);
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__pos_3d(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__pos_3d(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__pos_3d(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__pos_3d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__pos_3d(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__pos_3d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__pos_3d(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__eop_3d(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__eop_3d(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__eop_3d(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__eop_3d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__eop_3d(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__eop_3d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__eop_3d(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__vel_3d(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__vel_3d(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__vel_3d(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__vel_3d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__vel_3d(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__vel_3d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__vel_3d(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__angle_3d(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__angle_3d(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__angle_3d(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__angle_3d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__angle_3d(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__angle_3d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__angle_3d(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__quaternion(
  const void * untyped_member)
{
  (void)untyped_member;
  return 4;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__quaternion(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__quaternion(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__quaternion(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__quaternion(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__quaternion(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__quaternion(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__imu_gyro_3d(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__imu_gyro_3d(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__imu_gyro_3d(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__imu_gyro_3d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__imu_gyro_3d(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__imu_gyro_3d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__imu_gyro_3d(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__imu_acc_3d(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__imu_acc_3d(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__imu_acc_3d(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__imu_acc_3d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__imu_acc_3d(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__imu_acc_3d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__imu_acc_3d(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__nodes(
  const void * untyped_member)
{
  const netlink_msg__msg__LinktrackNode2__Sequence * member =
    (const netlink_msg__msg__LinktrackNode2__Sequence *)(untyped_member);
  return member->size;
}

const void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__nodes(
  const void * untyped_member, size_t index)
{
  const netlink_msg__msg__LinktrackNode2__Sequence * member =
    (const netlink_msg__msg__LinktrackNode2__Sequence *)(untyped_member);
  return &member->data[index];
}

void * netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__nodes(
  void * untyped_member, size_t index)
{
  netlink_msg__msg__LinktrackNode2__Sequence * member =
    (netlink_msg__msg__LinktrackNode2__Sequence *)(untyped_member);
  return &member->data[index];
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__nodes(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const netlink_msg__msg__LinktrackNode2 * item =
    ((const netlink_msg__msg__LinktrackNode2 *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__nodes(untyped_member, index));
  netlink_msg__msg__LinktrackNode2 * value =
    (netlink_msg__msg__LinktrackNode2 *)(untyped_value);
  *value = *item;
}

void netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__nodes(
  void * untyped_member, size_t index, const void * untyped_value)
{
  netlink_msg__msg__LinktrackNode2 * item =
    ((netlink_msg__msg__LinktrackNode2 *)
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__nodes(untyped_member, index));
  const netlink_msg__msg__LinktrackNode2 * value =
    (const netlink_msg__msg__LinktrackNode2 *)(untyped_value);
  *item = *value;
}

bool netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__resize_function__LinktrackNodeframe2__nodes(
  void * untyped_member, size_t size)
{
  netlink_msg__msg__LinktrackNode2__Sequence * member =
    (netlink_msg__msg__LinktrackNode2__Sequence *)(untyped_member);
  netlink_msg__msg__LinktrackNode2__Sequence__fini(member);
  return netlink_msg__msg__LinktrackNode2__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_member_array[13] = {
  {
    "role",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, role),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "local_time",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, local_time),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "system_time",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, system_time),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "voltage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, voltage),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pos_3d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, pos_3d),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__pos_3d,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__pos_3d,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__pos_3d,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__pos_3d,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__pos_3d,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "eop_3d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, eop_3d),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__eop_3d,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__eop_3d,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__eop_3d,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__eop_3d,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__eop_3d,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "vel_3d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, vel_3d),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__vel_3d,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__vel_3d,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__vel_3d,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__vel_3d,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__vel_3d,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "angle_3d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, angle_3d),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__angle_3d,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__angle_3d,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__angle_3d,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__angle_3d,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__angle_3d,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "quaternion",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    4,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, quaternion),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__quaternion,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__quaternion,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__quaternion,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__quaternion,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__quaternion,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "imu_gyro_3d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, imu_gyro_3d),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__imu_gyro_3d,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__imu_gyro_3d,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__imu_gyro_3d,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__imu_gyro_3d,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__imu_gyro_3d,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "imu_acc_3d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, imu_acc_3d),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__imu_acc_3d,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__imu_acc_3d,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__imu_acc_3d,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__imu_acc_3d,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__imu_acc_3d,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "nodes",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(netlink_msg__msg__LinktrackNodeframe2, nodes),  // bytes offset in struct
    NULL,  // default value
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__size_function__LinktrackNodeframe2__nodes,  // size() function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_const_function__LinktrackNodeframe2__nodes,  // get_const(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__get_function__LinktrackNodeframe2__nodes,  // get(index) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__fetch_function__LinktrackNodeframe2__nodes,  // fetch(index, &value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__assign_function__LinktrackNodeframe2__nodes,  // assign(index, value) function pointer
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__resize_function__LinktrackNodeframe2__nodes  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_members = {
  "netlink_msg__msg",  // message namespace
  "LinktrackNodeframe2",  // message name
  13,  // number of fields
  sizeof(netlink_msg__msg__LinktrackNodeframe2),
  netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_member_array,  // message members
  netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_init_function,  // function to initialize message memory (memory has to be allocated)
  netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_type_support_handle = {
  0,
  &netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_netlink_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, netlink_msg, msg, LinktrackNodeframe2)() {
  netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_member_array[12].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, netlink_msg, msg, LinktrackNode2)();
  if (!netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_type_support_handle.typesupport_identifier) {
    netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &netlink_msg__msg__LinktrackNodeframe2__rosidl_typesupport_introspection_c__LinktrackNodeframe2_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
