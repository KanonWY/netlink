// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/TofsenseMFrame0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__TOFSENSE_M_FRAME0_H_
#define NETLINK_MSG__MSG__TOFSENSE_M_FRAME0_H_

#include "netlink_msg/msg/detail/tofsense_m_frame0__struct.h"
#include "netlink_msg/msg/detail/tofsense_m_frame0__functions.h"
#include "netlink_msg/msg/detail/tofsense_m_frame0__type_support.h"

#endif  // NETLINK_MSG__MSG__TOFSENSE_M_FRAME0_H_
