// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackAoaNode0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_aoa_node0__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackAoaNode0_rx_rssi
{
public:
  explicit Init_LinktrackAoaNode0_rx_rssi(::netlink_msg::msg::LinktrackAoaNode0 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackAoaNode0 rx_rssi(::netlink_msg::msg::LinktrackAoaNode0::_rx_rssi_type arg)
  {
    msg_.rx_rssi = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNode0 msg_;
};

class Init_LinktrackAoaNode0_fp_rssi
{
public:
  explicit Init_LinktrackAoaNode0_fp_rssi(::netlink_msg::msg::LinktrackAoaNode0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNode0_rx_rssi fp_rssi(::netlink_msg::msg::LinktrackAoaNode0::_fp_rssi_type arg)
  {
    msg_.fp_rssi = std::move(arg);
    return Init_LinktrackAoaNode0_rx_rssi(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNode0 msg_;
};

class Init_LinktrackAoaNode0_angle
{
public:
  explicit Init_LinktrackAoaNode0_angle(::netlink_msg::msg::LinktrackAoaNode0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNode0_fp_rssi angle(::netlink_msg::msg::LinktrackAoaNode0::_angle_type arg)
  {
    msg_.angle = std::move(arg);
    return Init_LinktrackAoaNode0_fp_rssi(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNode0 msg_;
};

class Init_LinktrackAoaNode0_dis
{
public:
  explicit Init_LinktrackAoaNode0_dis(::netlink_msg::msg::LinktrackAoaNode0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNode0_angle dis(::netlink_msg::msg::LinktrackAoaNode0::_dis_type arg)
  {
    msg_.dis = std::move(arg);
    return Init_LinktrackAoaNode0_angle(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNode0 msg_;
};

class Init_LinktrackAoaNode0_id
{
public:
  explicit Init_LinktrackAoaNode0_id(::netlink_msg::msg::LinktrackAoaNode0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNode0_dis id(::netlink_msg::msg::LinktrackAoaNode0::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackAoaNode0_dis(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNode0 msg_;
};

class Init_LinktrackAoaNode0_role
{
public:
  Init_LinktrackAoaNode0_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackAoaNode0_id role(::netlink_msg::msg::LinktrackAoaNode0::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackAoaNode0_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNode0 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackAoaNode0>()
{
  return netlink_msg::msg::builder::Init_LinktrackAoaNode0_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODE0__BUILDER_HPP_
