// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackTagframe0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAGFRAME0__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAGFRAME0__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_tagframe0__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackTagframe0_imu_acc_3d
{
public:
  explicit Init_LinktrackTagframe0_imu_acc_3d(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackTagframe0 imu_acc_3d(::netlink_msg::msg::LinktrackTagframe0::_imu_acc_3d_type arg)
  {
    msg_.imu_acc_3d = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_imu_gyro_3d
{
public:
  explicit Init_LinktrackTagframe0_imu_gyro_3d(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_imu_acc_3d imu_gyro_3d(::netlink_msg::msg::LinktrackTagframe0::_imu_gyro_3d_type arg)
  {
    msg_.imu_gyro_3d = std::move(arg);
    return Init_LinktrackTagframe0_imu_acc_3d(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_quaternion
{
public:
  explicit Init_LinktrackTagframe0_quaternion(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_imu_gyro_3d quaternion(::netlink_msg::msg::LinktrackTagframe0::_quaternion_type arg)
  {
    msg_.quaternion = std::move(arg);
    return Init_LinktrackTagframe0_imu_gyro_3d(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_angle_3d
{
public:
  explicit Init_LinktrackTagframe0_angle_3d(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_quaternion angle_3d(::netlink_msg::msg::LinktrackTagframe0::_angle_3d_type arg)
  {
    msg_.angle_3d = std::move(arg);
    return Init_LinktrackTagframe0_quaternion(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_dis_arr
{
public:
  explicit Init_LinktrackTagframe0_dis_arr(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_angle_3d dis_arr(::netlink_msg::msg::LinktrackTagframe0::_dis_arr_type arg)
  {
    msg_.dis_arr = std::move(arg);
    return Init_LinktrackTagframe0_angle_3d(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_vel_3d
{
public:
  explicit Init_LinktrackTagframe0_vel_3d(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_dis_arr vel_3d(::netlink_msg::msg::LinktrackTagframe0::_vel_3d_type arg)
  {
    msg_.vel_3d = std::move(arg);
    return Init_LinktrackTagframe0_dis_arr(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_eop_3d
{
public:
  explicit Init_LinktrackTagframe0_eop_3d(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_vel_3d eop_3d(::netlink_msg::msg::LinktrackTagframe0::_eop_3d_type arg)
  {
    msg_.eop_3d = std::move(arg);
    return Init_LinktrackTagframe0_vel_3d(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_pos_3d
{
public:
  explicit Init_LinktrackTagframe0_pos_3d(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_eop_3d pos_3d(::netlink_msg::msg::LinktrackTagframe0::_pos_3d_type arg)
  {
    msg_.pos_3d = std::move(arg);
    return Init_LinktrackTagframe0_eop_3d(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_voltage
{
public:
  explicit Init_LinktrackTagframe0_voltage(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_pos_3d voltage(::netlink_msg::msg::LinktrackTagframe0::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_LinktrackTagframe0_pos_3d(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_system_time
{
public:
  explicit Init_LinktrackTagframe0_system_time(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_voltage system_time(::netlink_msg::msg::LinktrackTagframe0::_system_time_type arg)
  {
    msg_.system_time = std::move(arg);
    return Init_LinktrackTagframe0_voltage(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_local_time
{
public:
  explicit Init_LinktrackTagframe0_local_time(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_system_time local_time(::netlink_msg::msg::LinktrackTagframe0::_local_time_type arg)
  {
    msg_.local_time = std::move(arg);
    return Init_LinktrackTagframe0_system_time(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_id
{
public:
  explicit Init_LinktrackTagframe0_id(::netlink_msg::msg::LinktrackTagframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackTagframe0_local_time id(::netlink_msg::msg::LinktrackTagframe0::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackTagframe0_local_time(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

class Init_LinktrackTagframe0_role
{
public:
  Init_LinktrackTagframe0_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackTagframe0_id role(::netlink_msg::msg::LinktrackTagframe0::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackTagframe0_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTagframe0 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackTagframe0>()
{
  return netlink_msg::msg::builder::Init_LinktrackTagframe0_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAGFRAME0__BUILDER_HPP_
