// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackAoaNodeframe0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_aoa_nodeframe0__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackAoaNodeframe0_nodes
{
public:
  explicit Init_LinktrackAoaNodeframe0_nodes(::netlink_msg::msg::LinktrackAoaNodeframe0 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackAoaNodeframe0 nodes(::netlink_msg::msg::LinktrackAoaNodeframe0::_nodes_type arg)
  {
    msg_.nodes = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNodeframe0 msg_;
};

class Init_LinktrackAoaNodeframe0_voltage
{
public:
  explicit Init_LinktrackAoaNodeframe0_voltage(::netlink_msg::msg::LinktrackAoaNodeframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNodeframe0_nodes voltage(::netlink_msg::msg::LinktrackAoaNodeframe0::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_LinktrackAoaNodeframe0_nodes(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNodeframe0 msg_;
};

class Init_LinktrackAoaNodeframe0_system_time
{
public:
  explicit Init_LinktrackAoaNodeframe0_system_time(::netlink_msg::msg::LinktrackAoaNodeframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNodeframe0_voltage system_time(::netlink_msg::msg::LinktrackAoaNodeframe0::_system_time_type arg)
  {
    msg_.system_time = std::move(arg);
    return Init_LinktrackAoaNodeframe0_voltage(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNodeframe0 msg_;
};

class Init_LinktrackAoaNodeframe0_local_time
{
public:
  explicit Init_LinktrackAoaNodeframe0_local_time(::netlink_msg::msg::LinktrackAoaNodeframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNodeframe0_system_time local_time(::netlink_msg::msg::LinktrackAoaNodeframe0::_local_time_type arg)
  {
    msg_.local_time = std::move(arg);
    return Init_LinktrackAoaNodeframe0_system_time(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNodeframe0 msg_;
};

class Init_LinktrackAoaNodeframe0_id
{
public:
  explicit Init_LinktrackAoaNodeframe0_id(::netlink_msg::msg::LinktrackAoaNodeframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackAoaNodeframe0_local_time id(::netlink_msg::msg::LinktrackAoaNodeframe0::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackAoaNodeframe0_local_time(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNodeframe0 msg_;
};

class Init_LinktrackAoaNodeframe0_role
{
public:
  Init_LinktrackAoaNodeframe0_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackAoaNodeframe0_id role(::netlink_msg::msg::LinktrackAoaNodeframe0::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackAoaNodeframe0_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackAoaNodeframe0 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackAoaNodeframe0>()
{
  return netlink_msg::msg::builder::Init_LinktrackAoaNodeframe0_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__BUILDER_HPP_
