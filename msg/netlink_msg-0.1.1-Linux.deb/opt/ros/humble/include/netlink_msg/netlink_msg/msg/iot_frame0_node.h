// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/IotFrame0Node.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__IOT_FRAME0_NODE_H_
#define NETLINK_MSG__MSG__IOT_FRAME0_NODE_H_

#include "netlink_msg/msg/detail/iot_frame0_node__struct.h"
#include "netlink_msg/msg/detail/iot_frame0_node__functions.h"
#include "netlink_msg/msg/detail/iot_frame0_node__type_support.h"

#endif  // NETLINK_MSG__MSG__IOT_FRAME0_NODE_H_
