// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/LinktrackNode6.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE6__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE6__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'data'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/LinktrackNode6 in the package netlink_msg.
typedef struct netlink_msg__msg__LinktrackNode6
{
  uint8_t role;
  uint32_t id;
  rosidl_runtime_c__uint8__Sequence data;
} netlink_msg__msg__LinktrackNode6;

// Struct for a sequence of netlink_msg__msg__LinktrackNode6.
typedef struct netlink_msg__msg__LinktrackNode6__Sequence
{
  netlink_msg__msg__LinktrackNode6 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__LinktrackNode6__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODE6__STRUCT_H_
