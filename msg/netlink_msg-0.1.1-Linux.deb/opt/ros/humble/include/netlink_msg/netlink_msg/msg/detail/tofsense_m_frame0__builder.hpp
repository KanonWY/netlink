// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/TofsenseMFrame0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/tofsense_m_frame0__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_TofsenseMFrame0_pixels
{
public:
  explicit Init_TofsenseMFrame0_pixels(::netlink_msg::msg::TofsenseMFrame0 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::TofsenseMFrame0 pixels(::netlink_msg::msg::TofsenseMFrame0::_pixels_type arg)
  {
    msg_.pixels = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseMFrame0 msg_;
};

class Init_TofsenseMFrame0_pixel_count
{
public:
  explicit Init_TofsenseMFrame0_pixel_count(::netlink_msg::msg::TofsenseMFrame0 & msg)
  : msg_(msg)
  {}
  Init_TofsenseMFrame0_pixels pixel_count(::netlink_msg::msg::TofsenseMFrame0::_pixel_count_type arg)
  {
    msg_.pixel_count = std::move(arg);
    return Init_TofsenseMFrame0_pixels(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseMFrame0 msg_;
};

class Init_TofsenseMFrame0_system_time
{
public:
  explicit Init_TofsenseMFrame0_system_time(::netlink_msg::msg::TofsenseMFrame0 & msg)
  : msg_(msg)
  {}
  Init_TofsenseMFrame0_pixel_count system_time(::netlink_msg::msg::TofsenseMFrame0::_system_time_type arg)
  {
    msg_.system_time = std::move(arg);
    return Init_TofsenseMFrame0_pixel_count(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseMFrame0 msg_;
};

class Init_TofsenseMFrame0_id
{
public:
  Init_TofsenseMFrame0_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TofsenseMFrame0_system_time id(::netlink_msg::msg::TofsenseMFrame0::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_TofsenseMFrame0_system_time(msg_);
  }

private:
  ::netlink_msg::msg::TofsenseMFrame0 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::TofsenseMFrame0>()
{
  return netlink_msg::msg::builder::Init_TofsenseMFrame0_id();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__TOFSENSE_M_FRAME0__BUILDER_HPP_
