// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from netlink_msg:msg/LinktrackNodeframe4.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME4__STRUCT_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME4__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'tags'
#include "netlink_msg/msg/detail/linktrack_node4_tag__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__netlink_msg__msg__LinktrackNodeframe4 __attribute__((deprecated))
#else
# define DEPRECATED__netlink_msg__msg__LinktrackNodeframe4 __declspec(deprecated)
#endif

namespace netlink_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LinktrackNodeframe4_
{
  using Type = LinktrackNodeframe4_<ContainerAllocator>;

  explicit LinktrackNodeframe4_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->role = 0;
      this->id = 0;
      this->local_time = 0ul;
      this->system_time = 0ul;
      this->voltage = 0.0f;
    }
  }

  explicit LinktrackNodeframe4_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->role = 0;
      this->id = 0;
      this->local_time = 0ul;
      this->system_time = 0ul;
      this->voltage = 0.0f;
    }
  }

  // field types and members
  using _role_type =
    uint8_t;
  _role_type role;
  using _id_type =
    uint8_t;
  _id_type id;
  using _local_time_type =
    uint32_t;
  _local_time_type local_time;
  using _system_time_type =
    uint32_t;
  _system_time_type system_time;
  using _voltage_type =
    float;
  _voltage_type voltage;
  using _tags_type =
    std::vector<netlink_msg::msg::LinktrackNode4Tag_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<netlink_msg::msg::LinktrackNode4Tag_<ContainerAllocator>>>;
  _tags_type tags;

  // setters for named parameter idiom
  Type & set__role(
    const uint8_t & _arg)
  {
    this->role = _arg;
    return *this;
  }
  Type & set__id(
    const uint8_t & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__local_time(
    const uint32_t & _arg)
  {
    this->local_time = _arg;
    return *this;
  }
  Type & set__system_time(
    const uint32_t & _arg)
  {
    this->system_time = _arg;
    return *this;
  }
  Type & set__voltage(
    const float & _arg)
  {
    this->voltage = _arg;
    return *this;
  }
  Type & set__tags(
    const std::vector<netlink_msg::msg::LinktrackNode4Tag_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<netlink_msg::msg::LinktrackNode4Tag_<ContainerAllocator>>> & _arg)
  {
    this->tags = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator> *;
  using ConstRawPtr =
    const netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__netlink_msg__msg__LinktrackNodeframe4
    std::shared_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__netlink_msg__msg__LinktrackNodeframe4
    std::shared_ptr<netlink_msg::msg::LinktrackNodeframe4_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LinktrackNodeframe4_ & other) const
  {
    if (this->role != other.role) {
      return false;
    }
    if (this->id != other.id) {
      return false;
    }
    if (this->local_time != other.local_time) {
      return false;
    }
    if (this->system_time != other.system_time) {
      return false;
    }
    if (this->voltage != other.voltage) {
      return false;
    }
    if (this->tags != other.tags) {
      return false;
    }
    return true;
  }
  bool operator!=(const LinktrackNodeframe4_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LinktrackNodeframe4_

// alias to use template instance with default allocator
using LinktrackNodeframe4 =
  netlink_msg::msg::LinktrackNodeframe4_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME4__STRUCT_HPP_
