// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackTag.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_tag__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackTag_dis_arr
{
public:
  explicit Init_LinktrackTag_dis_arr(::netlink_msg::msg::LinktrackTag & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackTag dis_arr(::netlink_msg::msg::LinktrackTag::_dis_arr_type arg)
  {
    msg_.dis_arr = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTag msg_;
};

class Init_LinktrackTag_pos_3d
{
public:
  explicit Init_LinktrackTag_pos_3d(::netlink_msg::msg::LinktrackTag & msg)
  : msg_(msg)
  {}
  Init_LinktrackTag_dis_arr pos_3d(::netlink_msg::msg::LinktrackTag::_pos_3d_type arg)
  {
    msg_.pos_3d = std::move(arg);
    return Init_LinktrackTag_dis_arr(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTag msg_;
};

class Init_LinktrackTag_id
{
public:
  explicit Init_LinktrackTag_id(::netlink_msg::msg::LinktrackTag & msg)
  : msg_(msg)
  {}
  Init_LinktrackTag_pos_3d id(::netlink_msg::msg::LinktrackTag::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackTag_pos_3d(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTag msg_;
};

class Init_LinktrackTag_role
{
public:
  Init_LinktrackTag_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackTag_id role(::netlink_msg::msg::LinktrackTag::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackTag_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackTag msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackTag>()
{
  return netlink_msg::msg::builder::Init_LinktrackTag_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__BUILDER_HPP_
