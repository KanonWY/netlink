// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/LinktrackNodeframe0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME0__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME0__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/linktrack_nodeframe0__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_LinktrackNodeframe0_nodes
{
public:
  explicit Init_LinktrackNodeframe0_nodes(::netlink_msg::msg::LinktrackNodeframe0 & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::LinktrackNodeframe0 nodes(::netlink_msg::msg::LinktrackNodeframe0::_nodes_type arg)
  {
    msg_.nodes = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe0 msg_;
};

class Init_LinktrackNodeframe0_id
{
public:
  explicit Init_LinktrackNodeframe0_id(::netlink_msg::msg::LinktrackNodeframe0 & msg)
  : msg_(msg)
  {}
  Init_LinktrackNodeframe0_nodes id(::netlink_msg::msg::LinktrackNodeframe0::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_LinktrackNodeframe0_nodes(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe0 msg_;
};

class Init_LinktrackNodeframe0_role
{
public:
  Init_LinktrackNodeframe0_role()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LinktrackNodeframe0_id role(::netlink_msg::msg::LinktrackNodeframe0::_role_type arg)
  {
    msg_.role = std::move(arg);
    return Init_LinktrackNodeframe0_id(msg_);
  }

private:
  ::netlink_msg::msg::LinktrackNodeframe0 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::LinktrackNodeframe0>()
{
  return netlink_msg::msg::builder::Init_LinktrackNodeframe0_role();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME0__BUILDER_HPP_
