// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/TofsenseCascade.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/tofsense_frame0__struct.h"

/// Struct defined in msg/TofsenseCascade in the package netlink_msg.
typedef struct netlink_msg__msg__TofsenseCascade
{
  netlink_msg__msg__TofsenseFrame0__Sequence nodes;
} netlink_msg__msg__TofsenseCascade;

// Struct for a sequence of netlink_msg__msg__TofsenseCascade.
typedef struct netlink_msg__msg__TofsenseCascade__Sequence
{
  netlink_msg__msg__TofsenseCascade * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__TofsenseCascade__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__TOFSENSE_CASCADE__STRUCT_H_
