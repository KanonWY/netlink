// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/LinktrackNodeframe2.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME2__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME2__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/linktrack_node2__struct.h"

/// Struct defined in msg/LinktrackNodeframe2 in the package netlink_msg.
typedef struct netlink_msg__msg__LinktrackNodeframe2
{
  uint8_t role;
  uint8_t id;
  uint32_t local_time;
  uint32_t system_time;
  float voltage;
  float pos_3d[3];
  float eop_3d[3];
  float vel_3d[3];
  float angle_3d[3];
  float quaternion[4];
  float imu_gyro_3d[3];
  float imu_acc_3d[3];
  netlink_msg__msg__LinktrackNode2__Sequence nodes;
} netlink_msg__msg__LinktrackNodeframe2;

// Struct for a sequence of netlink_msg__msg__LinktrackNodeframe2.
typedef struct netlink_msg__msg__LinktrackNodeframe2__Sequence
{
  netlink_msg__msg__LinktrackNodeframe2 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__LinktrackNodeframe2__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME2__STRUCT_H_
