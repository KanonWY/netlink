// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from netlink_msg:msg/TofsenseCascade.idl
// generated code does not contain a copyright notice
#include "netlink_msg/msg/detail/tofsense_cascade__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `nodes`
#include "netlink_msg/msg/detail/tofsense_frame0__functions.h"

bool
netlink_msg__msg__TofsenseCascade__init(netlink_msg__msg__TofsenseCascade * msg)
{
  if (!msg) {
    return false;
  }
  // nodes
  if (!netlink_msg__msg__TofsenseFrame0__Sequence__init(&msg->nodes, 0)) {
    netlink_msg__msg__TofsenseCascade__fini(msg);
    return false;
  }
  return true;
}

void
netlink_msg__msg__TofsenseCascade__fini(netlink_msg__msg__TofsenseCascade * msg)
{
  if (!msg) {
    return;
  }
  // nodes
  netlink_msg__msg__TofsenseFrame0__Sequence__fini(&msg->nodes);
}

bool
netlink_msg__msg__TofsenseCascade__are_equal(const netlink_msg__msg__TofsenseCascade * lhs, const netlink_msg__msg__TofsenseCascade * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // nodes
  if (!netlink_msg__msg__TofsenseFrame0__Sequence__are_equal(
      &(lhs->nodes), &(rhs->nodes)))
  {
    return false;
  }
  return true;
}

bool
netlink_msg__msg__TofsenseCascade__copy(
  const netlink_msg__msg__TofsenseCascade * input,
  netlink_msg__msg__TofsenseCascade * output)
{
  if (!input || !output) {
    return false;
  }
  // nodes
  if (!netlink_msg__msg__TofsenseFrame0__Sequence__copy(
      &(input->nodes), &(output->nodes)))
  {
    return false;
  }
  return true;
}

netlink_msg__msg__TofsenseCascade *
netlink_msg__msg__TofsenseCascade__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__TofsenseCascade * msg = (netlink_msg__msg__TofsenseCascade *)allocator.allocate(sizeof(netlink_msg__msg__TofsenseCascade), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(netlink_msg__msg__TofsenseCascade));
  bool success = netlink_msg__msg__TofsenseCascade__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
netlink_msg__msg__TofsenseCascade__destroy(netlink_msg__msg__TofsenseCascade * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    netlink_msg__msg__TofsenseCascade__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
netlink_msg__msg__TofsenseCascade__Sequence__init(netlink_msg__msg__TofsenseCascade__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__TofsenseCascade * data = NULL;

  if (size) {
    data = (netlink_msg__msg__TofsenseCascade *)allocator.zero_allocate(size, sizeof(netlink_msg__msg__TofsenseCascade), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = netlink_msg__msg__TofsenseCascade__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        netlink_msg__msg__TofsenseCascade__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
netlink_msg__msg__TofsenseCascade__Sequence__fini(netlink_msg__msg__TofsenseCascade__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      netlink_msg__msg__TofsenseCascade__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

netlink_msg__msg__TofsenseCascade__Sequence *
netlink_msg__msg__TofsenseCascade__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  netlink_msg__msg__TofsenseCascade__Sequence * array = (netlink_msg__msg__TofsenseCascade__Sequence *)allocator.allocate(sizeof(netlink_msg__msg__TofsenseCascade__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = netlink_msg__msg__TofsenseCascade__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
netlink_msg__msg__TofsenseCascade__Sequence__destroy(netlink_msg__msg__TofsenseCascade__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    netlink_msg__msg__TofsenseCascade__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
netlink_msg__msg__TofsenseCascade__Sequence__are_equal(const netlink_msg__msg__TofsenseCascade__Sequence * lhs, const netlink_msg__msg__TofsenseCascade__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!netlink_msg__msg__TofsenseCascade__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
netlink_msg__msg__TofsenseCascade__Sequence__copy(
  const netlink_msg__msg__TofsenseCascade__Sequence * input,
  netlink_msg__msg__TofsenseCascade__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(netlink_msg__msg__TofsenseCascade);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    netlink_msg__msg__TofsenseCascade * data =
      (netlink_msg__msg__TofsenseCascade *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!netlink_msg__msg__TofsenseCascade__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          netlink_msg__msg__TofsenseCascade__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!netlink_msg__msg__TofsenseCascade__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
