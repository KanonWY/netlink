// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/LinktrackAoaNodeframe0.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/linktrack_aoa_node0__struct.h"

/// Struct defined in msg/LinktrackAoaNodeframe0 in the package netlink_msg.
typedef struct netlink_msg__msg__LinktrackAoaNodeframe0
{
  uint8_t role;
  uint8_t id;
  uint32_t local_time;
  uint32_t system_time;
  float voltage;
  netlink_msg__msg__LinktrackAoaNode0__Sequence nodes;
} netlink_msg__msg__LinktrackAoaNodeframe0;

// Struct for a sequence of netlink_msg__msg__LinktrackAoaNodeframe0.
typedef struct netlink_msg__msg__LinktrackAoaNodeframe0__Sequence
{
  netlink_msg__msg__LinktrackAoaNodeframe0 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__LinktrackAoaNodeframe0__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_AOA_NODEFRAME0__STRUCT_H_
