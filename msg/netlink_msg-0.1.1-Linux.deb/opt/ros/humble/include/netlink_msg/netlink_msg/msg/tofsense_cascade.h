// generated from rosidl_generator_c/resource/idl.h.em
// with input from netlink_msg:msg/TofsenseCascade.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__TOFSENSE_CASCADE_H_
#define NETLINK_MSG__MSG__TOFSENSE_CASCADE_H_

#include "netlink_msg/msg/detail/tofsense_cascade__struct.h"
#include "netlink_msg/msg/detail/tofsense_cascade__functions.h"
#include "netlink_msg/msg/detail/tofsense_cascade__type_support.h"

#endif  // NETLINK_MSG__MSG__TOFSENSE_CASCADE_H_
