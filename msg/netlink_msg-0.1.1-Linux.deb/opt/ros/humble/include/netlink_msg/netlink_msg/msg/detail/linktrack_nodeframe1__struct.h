// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/LinktrackNodeframe1.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME1__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME1__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/linktrack_node1__struct.h"

/// Struct defined in msg/LinktrackNodeframe1 in the package netlink_msg.
typedef struct netlink_msg__msg__LinktrackNodeframe1
{
  uint8_t role;
  uint8_t id;
  uint32_t local_time;
  uint32_t system_time;
  float voltage;
  netlink_msg__msg__LinktrackNode1__Sequence nodes;
} netlink_msg__msg__LinktrackNodeframe1;

// Struct for a sequence of netlink_msg__msg__LinktrackNodeframe1.
typedef struct netlink_msg__msg__LinktrackNodeframe1__Sequence
{
  netlink_msg__msg__LinktrackNodeframe1 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__LinktrackNodeframe1__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME1__STRUCT_H_
