// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from netlink_msg:msg/LinktrackNodeframe6.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME6__STRUCT_H_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME6__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'nodes'
#include "netlink_msg/msg/detail/linktrack_node6__struct.h"

/// Struct defined in msg/LinktrackNodeframe6 in the package netlink_msg.
typedef struct netlink_msg__msg__LinktrackNodeframe6
{
  uint8_t role;
  uint32_t id;
  netlink_msg__msg__LinktrackNode6__Sequence nodes;
} netlink_msg__msg__LinktrackNodeframe6;

// Struct for a sequence of netlink_msg__msg__LinktrackNodeframe6.
typedef struct netlink_msg__msg__LinktrackNodeframe6__Sequence
{
  netlink_msg__msg__LinktrackNodeframe6 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} netlink_msg__msg__LinktrackNodeframe6__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_NODEFRAME6__STRUCT_H_
