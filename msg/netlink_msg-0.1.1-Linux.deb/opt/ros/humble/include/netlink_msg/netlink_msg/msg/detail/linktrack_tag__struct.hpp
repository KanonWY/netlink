// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from netlink_msg:msg/LinktrackTag.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__STRUCT_HPP_
#define NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__netlink_msg__msg__LinktrackTag __attribute__((deprecated))
#else
# define DEPRECATED__netlink_msg__msg__LinktrackTag __declspec(deprecated)
#endif

namespace netlink_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LinktrackTag_
{
  using Type = LinktrackTag_<ContainerAllocator>;

  explicit LinktrackTag_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->role = 0;
      this->id = 0;
      std::fill<typename std::array<float, 3>::iterator, float>(this->pos_3d.begin(), this->pos_3d.end(), 0.0f);
      std::fill<typename std::array<float, 8>::iterator, float>(this->dis_arr.begin(), this->dis_arr.end(), 0.0f);
    }
  }

  explicit LinktrackTag_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pos_3d(_alloc),
    dis_arr(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->role = 0;
      this->id = 0;
      std::fill<typename std::array<float, 3>::iterator, float>(this->pos_3d.begin(), this->pos_3d.end(), 0.0f);
      std::fill<typename std::array<float, 8>::iterator, float>(this->dis_arr.begin(), this->dis_arr.end(), 0.0f);
    }
  }

  // field types and members
  using _role_type =
    uint8_t;
  _role_type role;
  using _id_type =
    uint8_t;
  _id_type id;
  using _pos_3d_type =
    std::array<float, 3>;
  _pos_3d_type pos_3d;
  using _dis_arr_type =
    std::array<float, 8>;
  _dis_arr_type dis_arr;

  // setters for named parameter idiom
  Type & set__role(
    const uint8_t & _arg)
  {
    this->role = _arg;
    return *this;
  }
  Type & set__id(
    const uint8_t & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__pos_3d(
    const std::array<float, 3> & _arg)
  {
    this->pos_3d = _arg;
    return *this;
  }
  Type & set__dis_arr(
    const std::array<float, 8> & _arg)
  {
    this->dis_arr = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    netlink_msg::msg::LinktrackTag_<ContainerAllocator> *;
  using ConstRawPtr =
    const netlink_msg::msg::LinktrackTag_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::LinktrackTag_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      netlink_msg::msg::LinktrackTag_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__netlink_msg__msg__LinktrackTag
    std::shared_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__netlink_msg__msg__LinktrackTag
    std::shared_ptr<netlink_msg::msg::LinktrackTag_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LinktrackTag_ & other) const
  {
    if (this->role != other.role) {
      return false;
    }
    if (this->id != other.id) {
      return false;
    }
    if (this->pos_3d != other.pos_3d) {
      return false;
    }
    if (this->dis_arr != other.dis_arr) {
      return false;
    }
    return true;
  }
  bool operator!=(const LinktrackTag_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LinktrackTag_

// alias to use template instance with default allocator
using LinktrackTag =
  netlink_msg::msg::LinktrackTag_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__LINKTRACK_TAG__STRUCT_HPP_
