// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from netlink_msg:msg/IotFrame0Node.idl
// generated code does not contain a copyright notice

#ifndef NETLINK_MSG__MSG__DETAIL__IOT_FRAME0_NODE__BUILDER_HPP_
#define NETLINK_MSG__MSG__DETAIL__IOT_FRAME0_NODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "netlink_msg/msg/detail/iot_frame0_node__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace netlink_msg
{

namespace msg
{

namespace builder
{

class Init_IotFrame0Node_user_data
{
public:
  explicit Init_IotFrame0Node_user_data(::netlink_msg::msg::IotFrame0Node & msg)
  : msg_(msg)
  {}
  ::netlink_msg::msg::IotFrame0Node user_data(::netlink_msg::msg::IotFrame0Node::_user_data_type arg)
  {
    msg_.user_data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0Node msg_;
};

class Init_IotFrame0Node_rx_rssi
{
public:
  explicit Init_IotFrame0Node_rx_rssi(::netlink_msg::msg::IotFrame0Node & msg)
  : msg_(msg)
  {}
  Init_IotFrame0Node_user_data rx_rssi(::netlink_msg::msg::IotFrame0Node::_rx_rssi_type arg)
  {
    msg_.rx_rssi = std::move(arg);
    return Init_IotFrame0Node_user_data(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0Node msg_;
};

class Init_IotFrame0Node_fp_rssi
{
public:
  explicit Init_IotFrame0Node_fp_rssi(::netlink_msg::msg::IotFrame0Node & msg)
  : msg_(msg)
  {}
  Init_IotFrame0Node_rx_rssi fp_rssi(::netlink_msg::msg::IotFrame0Node::_fp_rssi_type arg)
  {
    msg_.fp_rssi = std::move(arg);
    return Init_IotFrame0Node_rx_rssi(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0Node msg_;
};

class Init_IotFrame0Node_aoa_angle_vertical
{
public:
  explicit Init_IotFrame0Node_aoa_angle_vertical(::netlink_msg::msg::IotFrame0Node & msg)
  : msg_(msg)
  {}
  Init_IotFrame0Node_fp_rssi aoa_angle_vertical(::netlink_msg::msg::IotFrame0Node::_aoa_angle_vertical_type arg)
  {
    msg_.aoa_angle_vertical = std::move(arg);
    return Init_IotFrame0Node_fp_rssi(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0Node msg_;
};

class Init_IotFrame0Node_aoa_angle_horizontal
{
public:
  explicit Init_IotFrame0Node_aoa_angle_horizontal(::netlink_msg::msg::IotFrame0Node & msg)
  : msg_(msg)
  {}
  Init_IotFrame0Node_aoa_angle_vertical aoa_angle_horizontal(::netlink_msg::msg::IotFrame0Node::_aoa_angle_horizontal_type arg)
  {
    msg_.aoa_angle_horizontal = std::move(arg);
    return Init_IotFrame0Node_aoa_angle_vertical(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0Node msg_;
};

class Init_IotFrame0Node_dis
{
public:
  explicit Init_IotFrame0Node_dis(::netlink_msg::msg::IotFrame0Node & msg)
  : msg_(msg)
  {}
  Init_IotFrame0Node_aoa_angle_horizontal dis(::netlink_msg::msg::IotFrame0Node::_dis_type arg)
  {
    msg_.dis = std::move(arg);
    return Init_IotFrame0Node_aoa_angle_horizontal(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0Node msg_;
};

class Init_IotFrame0Node_uid
{
public:
  Init_IotFrame0Node_uid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_IotFrame0Node_dis uid(::netlink_msg::msg::IotFrame0Node::_uid_type arg)
  {
    msg_.uid = std::move(arg);
    return Init_IotFrame0Node_dis(msg_);
  }

private:
  ::netlink_msg::msg::IotFrame0Node msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::netlink_msg::msg::IotFrame0Node>()
{
  return netlink_msg::msg::builder::Init_IotFrame0Node_uid();
}

}  // namespace netlink_msg

#endif  // NETLINK_MSG__MSG__DETAIL__IOT_FRAME0_NODE__BUILDER_HPP_
