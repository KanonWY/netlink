# generated from rosidl_generator_py/resource/_idl.py.em
# with input from netlink_msg:msg/LinktrackAoaNode0.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_LinktrackAoaNode0(type):
    """Metaclass of message 'LinktrackAoaNode0'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('netlink_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'netlink_msg.msg.LinktrackAoaNode0')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__linktrack_aoa_node0
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__linktrack_aoa_node0
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__linktrack_aoa_node0
            cls._TYPE_SUPPORT = module.type_support_msg__msg__linktrack_aoa_node0
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__linktrack_aoa_node0

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class LinktrackAoaNode0(metaclass=Metaclass_LinktrackAoaNode0):
    """Message class 'LinktrackAoaNode0'."""

    __slots__ = [
        '_role',
        '_id',
        '_dis',
        '_angle',
        '_fp_rssi',
        '_rx_rssi',
    ]

    _fields_and_field_types = {
        'role': 'uint8',
        'id': 'uint8',
        'dis': 'float',
        'angle': 'float',
        'fp_rssi': 'float',
        'rx_rssi': 'float',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.role = kwargs.get('role', int())
        self.id = kwargs.get('id', int())
        self.dis = kwargs.get('dis', float())
        self.angle = kwargs.get('angle', float())
        self.fp_rssi = kwargs.get('fp_rssi', float())
        self.rx_rssi = kwargs.get('rx_rssi', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.role != other.role:
            return False
        if self.id != other.id:
            return False
        if self.dis != other.dis:
            return False
        if self.angle != other.angle:
            return False
        if self.fp_rssi != other.fp_rssi:
            return False
        if self.rx_rssi != other.rx_rssi:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def role(self):
        """Message field 'role'."""
        return self._role

    @role.setter
    def role(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'role' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'role' field must be an unsigned integer in [0, 255]"
        self._role = value

    @builtins.property  # noqa: A003
    def id(self):  # noqa: A003
        """Message field 'id'."""
        return self._id

    @id.setter  # noqa: A003
    def id(self, value):  # noqa: A003
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'id' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'id' field must be an unsigned integer in [0, 255]"
        self._id = value

    @builtins.property
    def dis(self):
        """Message field 'dis'."""
        return self._dis

    @dis.setter
    def dis(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'dis' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'dis' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._dis = value

    @builtins.property
    def angle(self):
        """Message field 'angle'."""
        return self._angle

    @angle.setter
    def angle(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'angle' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'angle' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._angle = value

    @builtins.property
    def fp_rssi(self):
        """Message field 'fp_rssi'."""
        return self._fp_rssi

    @fp_rssi.setter
    def fp_rssi(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'fp_rssi' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'fp_rssi' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._fp_rssi = value

    @builtins.property
    def rx_rssi(self):
        """Message field 'rx_rssi'."""
        return self._rx_rssi

    @rx_rssi.setter
    def rx_rssi(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'rx_rssi' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'rx_rssi' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._rx_rssi = value
