# generated from rosidl_generator_py/resource/_idl.py.em
# with input from netlink_msg:msg/LinktrackTagframe0.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

# Member 'pos_3d'
# Member 'eop_3d'
# Member 'vel_3d'
# Member 'dis_arr'
# Member 'angle_3d'
# Member 'quaternion'
# Member 'imu_gyro_3d'
# Member 'imu_acc_3d'
import numpy  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_LinktrackTagframe0(type):
    """Metaclass of message 'LinktrackTagframe0'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('netlink_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'netlink_msg.msg.LinktrackTagframe0')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__linktrack_tagframe0
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__linktrack_tagframe0
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__linktrack_tagframe0
            cls._TYPE_SUPPORT = module.type_support_msg__msg__linktrack_tagframe0
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__linktrack_tagframe0

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class LinktrackTagframe0(metaclass=Metaclass_LinktrackTagframe0):
    """Message class 'LinktrackTagframe0'."""

    __slots__ = [
        '_role',
        '_id',
        '_local_time',
        '_system_time',
        '_voltage',
        '_pos_3d',
        '_eop_3d',
        '_vel_3d',
        '_dis_arr',
        '_angle_3d',
        '_quaternion',
        '_imu_gyro_3d',
        '_imu_acc_3d',
    ]

    _fields_and_field_types = {
        'role': 'uint8',
        'id': 'uint8',
        'local_time': 'uint32',
        'system_time': 'uint32',
        'voltage': 'float',
        'pos_3d': 'float[3]',
        'eop_3d': 'float[3]',
        'vel_3d': 'float[3]',
        'dis_arr': 'float[8]',
        'angle_3d': 'float[3]',
        'quaternion': 'float[4]',
        'imu_gyro_3d': 'float[3]',
        'imu_acc_3d': 'float[3]',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 3),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 3),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 3),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 8),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 3),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 4),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 3),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 3),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.role = kwargs.get('role', int())
        self.id = kwargs.get('id', int())
        self.local_time = kwargs.get('local_time', int())
        self.system_time = kwargs.get('system_time', int())
        self.voltage = kwargs.get('voltage', float())
        if 'pos_3d' not in kwargs:
            self.pos_3d = numpy.zeros(3, dtype=numpy.float32)
        else:
            self.pos_3d = numpy.array(kwargs.get('pos_3d'), dtype=numpy.float32)
            assert self.pos_3d.shape == (3, )
        if 'eop_3d' not in kwargs:
            self.eop_3d = numpy.zeros(3, dtype=numpy.float32)
        else:
            self.eop_3d = numpy.array(kwargs.get('eop_3d'), dtype=numpy.float32)
            assert self.eop_3d.shape == (3, )
        if 'vel_3d' not in kwargs:
            self.vel_3d = numpy.zeros(3, dtype=numpy.float32)
        else:
            self.vel_3d = numpy.array(kwargs.get('vel_3d'), dtype=numpy.float32)
            assert self.vel_3d.shape == (3, )
        if 'dis_arr' not in kwargs:
            self.dis_arr = numpy.zeros(8, dtype=numpy.float32)
        else:
            self.dis_arr = numpy.array(kwargs.get('dis_arr'), dtype=numpy.float32)
            assert self.dis_arr.shape == (8, )
        if 'angle_3d' not in kwargs:
            self.angle_3d = numpy.zeros(3, dtype=numpy.float32)
        else:
            self.angle_3d = numpy.array(kwargs.get('angle_3d'), dtype=numpy.float32)
            assert self.angle_3d.shape == (3, )
        if 'quaternion' not in kwargs:
            self.quaternion = numpy.zeros(4, dtype=numpy.float32)
        else:
            self.quaternion = numpy.array(kwargs.get('quaternion'), dtype=numpy.float32)
            assert self.quaternion.shape == (4, )
        if 'imu_gyro_3d' not in kwargs:
            self.imu_gyro_3d = numpy.zeros(3, dtype=numpy.float32)
        else:
            self.imu_gyro_3d = numpy.array(kwargs.get('imu_gyro_3d'), dtype=numpy.float32)
            assert self.imu_gyro_3d.shape == (3, )
        if 'imu_acc_3d' not in kwargs:
            self.imu_acc_3d = numpy.zeros(3, dtype=numpy.float32)
        else:
            self.imu_acc_3d = numpy.array(kwargs.get('imu_acc_3d'), dtype=numpy.float32)
            assert self.imu_acc_3d.shape == (3, )

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.role != other.role:
            return False
        if self.id != other.id:
            return False
        if self.local_time != other.local_time:
            return False
        if self.system_time != other.system_time:
            return False
        if self.voltage != other.voltage:
            return False
        if all(self.pos_3d != other.pos_3d):
            return False
        if all(self.eop_3d != other.eop_3d):
            return False
        if all(self.vel_3d != other.vel_3d):
            return False
        if all(self.dis_arr != other.dis_arr):
            return False
        if all(self.angle_3d != other.angle_3d):
            return False
        if all(self.quaternion != other.quaternion):
            return False
        if all(self.imu_gyro_3d != other.imu_gyro_3d):
            return False
        if all(self.imu_acc_3d != other.imu_acc_3d):
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def role(self):
        """Message field 'role'."""
        return self._role

    @role.setter
    def role(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'role' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'role' field must be an unsigned integer in [0, 255]"
        self._role = value

    @builtins.property  # noqa: A003
    def id(self):  # noqa: A003
        """Message field 'id'."""
        return self._id

    @id.setter  # noqa: A003
    def id(self, value):  # noqa: A003
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'id' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'id' field must be an unsigned integer in [0, 255]"
        self._id = value

    @builtins.property
    def local_time(self):
        """Message field 'local_time'."""
        return self._local_time

    @local_time.setter
    def local_time(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'local_time' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'local_time' field must be an unsigned integer in [0, 4294967295]"
        self._local_time = value

    @builtins.property
    def system_time(self):
        """Message field 'system_time'."""
        return self._system_time

    @system_time.setter
    def system_time(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'system_time' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'system_time' field must be an unsigned integer in [0, 4294967295]"
        self._system_time = value

    @builtins.property
    def voltage(self):
        """Message field 'voltage'."""
        return self._voltage

    @voltage.setter
    def voltage(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'voltage' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'voltage' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._voltage = value

    @builtins.property
    def pos_3d(self):
        """Message field 'pos_3d'."""
        return self._pos_3d

    @pos_3d.setter
    def pos_3d(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'pos_3d' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 3, \
                "The 'pos_3d' numpy.ndarray() must have a size of 3"
            self._pos_3d = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 3 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'pos_3d' field must be a set or sequence with length 3 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._pos_3d = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def eop_3d(self):
        """Message field 'eop_3d'."""
        return self._eop_3d

    @eop_3d.setter
    def eop_3d(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'eop_3d' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 3, \
                "The 'eop_3d' numpy.ndarray() must have a size of 3"
            self._eop_3d = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 3 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'eop_3d' field must be a set or sequence with length 3 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._eop_3d = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def vel_3d(self):
        """Message field 'vel_3d'."""
        return self._vel_3d

    @vel_3d.setter
    def vel_3d(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'vel_3d' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 3, \
                "The 'vel_3d' numpy.ndarray() must have a size of 3"
            self._vel_3d = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 3 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'vel_3d' field must be a set or sequence with length 3 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._vel_3d = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def dis_arr(self):
        """Message field 'dis_arr'."""
        return self._dis_arr

    @dis_arr.setter
    def dis_arr(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'dis_arr' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 8, \
                "The 'dis_arr' numpy.ndarray() must have a size of 8"
            self._dis_arr = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 8 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'dis_arr' field must be a set or sequence with length 8 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._dis_arr = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def angle_3d(self):
        """Message field 'angle_3d'."""
        return self._angle_3d

    @angle_3d.setter
    def angle_3d(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'angle_3d' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 3, \
                "The 'angle_3d' numpy.ndarray() must have a size of 3"
            self._angle_3d = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 3 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'angle_3d' field must be a set or sequence with length 3 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._angle_3d = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def quaternion(self):
        """Message field 'quaternion'."""
        return self._quaternion

    @quaternion.setter
    def quaternion(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'quaternion' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 4, \
                "The 'quaternion' numpy.ndarray() must have a size of 4"
            self._quaternion = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 4 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'quaternion' field must be a set or sequence with length 4 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._quaternion = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def imu_gyro_3d(self):
        """Message field 'imu_gyro_3d'."""
        return self._imu_gyro_3d

    @imu_gyro_3d.setter
    def imu_gyro_3d(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'imu_gyro_3d' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 3, \
                "The 'imu_gyro_3d' numpy.ndarray() must have a size of 3"
            self._imu_gyro_3d = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 3 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'imu_gyro_3d' field must be a set or sequence with length 3 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._imu_gyro_3d = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def imu_acc_3d(self):
        """Message field 'imu_acc_3d'."""
        return self._imu_acc_3d

    @imu_acc_3d.setter
    def imu_acc_3d(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'imu_acc_3d' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 3, \
                "The 'imu_acc_3d' numpy.ndarray() must have a size of 3"
            self._imu_acc_3d = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 3 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'imu_acc_3d' field must be a set or sequence with length 3 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._imu_acc_3d = numpy.array(value, dtype=numpy.float32)
